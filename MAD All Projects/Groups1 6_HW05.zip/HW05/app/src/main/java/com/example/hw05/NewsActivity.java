package com.example.hw05;
/*
* Assignment- HW05
* File Name- NewsActivity.java
* Groups1 6- Siddharth Panda, Nayana Naik*/
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.ProgressBar;

import org.json.JSONArray;
import org.json.JSONObject;
import org.apache.commons.io.IOUtils;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class NewsActivity extends AppCompatActivity {

    //TextView tv_sample;
    ListView lv_news_items_list;
    //ProgressBar pb_loading_news;
    FrameLayout fl_loading_stories;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        lv_news_items_list=(ListView) findViewById(R.id.lv_news_item);
       // pb_loading_news=(ProgressBar)findViewById(R.id.pb_loading_news);
        fl_loading_stories=(FrameLayout)findViewById(R.id.progressBar_with_message_frame_layout_news);
        fl_loading_stories.setVisibility(View.INVISIBLE);
        Intent fromMain=getIntent();
        Bundle getBundle=getIntent().getExtras();
        HashMap<String, String> sourceHashMap= (HashMap<String, String>) getBundle.getSerializable("sourceHashMap");
        String value=getBundle.getString("clickedItem");
        setTitle(value);
        String key=null;
        for(Map.Entry entry: sourceHashMap.entrySet()){
            if(value.equals(entry.getValue())){
                key = (String)entry.getKey();
            }
        }

        String newsURL="https://newsapi.org/v2/top-headlines?sources="+key+"&apiKey=40b2155e475240baab718bf95d49b3d8";
        new GetNewsData().execute(newsURL);


    }

    private class GetNewsData extends AsyncTask<String, Void, ArrayList<News>>{
        @Override
        protected void onPreExecute() {
            //super.onPreExecute();
            //pb_loading_news.setVisibility(View.VISIBLE);
            fl_loading_stories.setVisibility(View.VISIBLE);

        }

        @Override
        protected void onPostExecute(ArrayList<News> news) {
           // pb_loading_news.setVisibility(View.INVISIBLE);
            fl_loading_stories.setVisibility(View.INVISIBLE);

            Log.d("NewsActivity",news.toString());
            final ArrayList<News> newsList=news;
            final NewsAdapter newsAdapter=new NewsAdapter(NewsActivity.this, R.layout.news_item,newsList);

            NewsActivity.this.lv_news_items_list.setAdapter(newsAdapter);
            NewsActivity.this.lv_news_items_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                    Intent toWebView=new Intent(NewsActivity.this, WebViewActivity.class);
                    Bundle dataBundleToWebView=new Bundle();
                   // dataBundle.putSerializable("sourceHashMap",sourceHashMap);

                    String url=newsAdapter.getNewsItemURL(position);
                    dataBundleToWebView.putString("clickedNewsItem",url);
                    Log.d("NewsURL",url);
                    toWebView.putExtras(dataBundleToWebView);
                    startActivity(toWebView);
                }
            });



        }

        @Override
        protected ArrayList<News> doInBackground(String... strings) {

            HttpURLConnection connection = null;
            ArrayList<News> resultArticle = new ArrayList<>();
            try {
                URL url = new URL(strings[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF8");

                    JSONObject root = new JSONObject(json);
                    JSONArray newsFromSource = root.getJSONArray("articles");
                    for (int i=0;i<newsFromSource.length();i++) {
                        JSONObject articleJson = newsFromSource.getJSONObject(i);
                        News news = new News();
                        news.title = articleJson.getString("title");
                        news.url=articleJson.getString("url");
                        news.urlToImage=articleJson.getString("urlToImage");
                        news.publishedAt=articleJson.getString("publishedAt");
                        if(articleJson.isNull("author")){
                            news.author="No Author Found";
                        }
                        else{
                            news.author=articleJson.getString("author");
                        }


                        resultArticle.add(news);
                    }
                }
            } catch (Exception e) {
                //Handle Exceptions
            } finally {
                //Close the connections
            }
            return resultArticle;

        }
    }






}

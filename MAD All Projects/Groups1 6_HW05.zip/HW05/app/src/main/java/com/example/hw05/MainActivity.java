package com.example.hw05;
/*
 * Assignment- HW05
 * File Name- MainActivity.java
 * Groups1 6- Siddharth Panda, Nayana Naik*/
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;


public class MainActivity extends AppCompatActivity {

    ProgressBar pb_loading_source;
    ListView lv_sources;
    FrameLayout fl_progressBar_with_message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       // pb_loading_source=(ProgressBar)findViewById(R.id.progressBar_loading_source);
        //pb_loading_source.setVisibility(View.INVISIBLE);
        fl_progressBar_with_message=(FrameLayout)findViewById(R.id.progressBar_with_message_frame_layout);
        fl_progressBar_with_message.setVisibility(View.INVISIBLE);
        lv_sources=(ListView)findViewById(R.id.listView_sources);

        if(!isConnected()){
            Toast.makeText(MainActivity.this,"Internet not connected",Toast.LENGTH_SHORT).show();
        }
        else{
            String sourceURL="https://newsapi.org/v2/sources?apiKey=40b2155e475240baab718bf95d49b3d8";
            new GetSources().execute(sourceURL);

        }


    }




    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    private class GetSources extends AsyncTask<String, Void, HashMap<String, String>>{

        @Override
        protected void onPreExecute() {
            //super.onPreExecute();
           // pb_loading_source.setVisibility(View.VISIBLE);
            fl_progressBar_with_message.setVisibility(View.VISIBLE);

        }

        @Override
        protected void onPostExecute(final HashMap<String, String> sourceHashMap) {

            //super.onPostExecute(stringStringHashMap);
            //pb_loading_source.setVisibility(View.INVISIBLE);
            fl_progressBar_with_message.setVisibility(View.INVISIBLE);
            //Log.d("ResultKey",sourceHashMap.toString());
            List valueArrayList=new ArrayList();
            Set keySet = sourceHashMap.keySet();
            Iterator it = keySet.iterator();
            while (it.hasNext()) {
                String key = (String) it.next();
                Object value = (Object) sourceHashMap.get(key);
                // do stuff here
                valueArrayList.add(value.toString());
            }
            Log.d("RArray",valueArrayList.toString());
            final ArrayAdapter<String> adapter=new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1,android.R.id.text1,valueArrayList);
            MainActivity.this.lv_sources.setAdapter(adapter);
            MainActivity.this.lv_sources.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                    //Log.d("ListView","Clicked Item "+position+" id "+id);
                    Intent toNews=new Intent(MainActivity.this,NewsActivity.class);
                    Bundle dataBundle=new Bundle();
                    dataBundle.putSerializable("sourceHashMap",sourceHashMap);

                    String item=(String)adapterView.getItemAtPosition(position);
                    //Log.d("item",item);
                    dataBundle.putString("clickedItem",item);
                    toNews.putExtras(dataBundle);
                    startActivity(toNews);
                    //toNews.
                }
            });

        }

        @Override
        protected HashMap<String, String> doInBackground(String... strings) {

            HttpURLConnection connection = null;
            //ArrayList<Article> resultArticle = new ArrayList<>();
            HashMap<String, String> sourceHashMap=new HashMap<>();
            try {
                URL url = new URL(strings[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF8");

                    JSONObject root = new JSONObject(json);
                    JSONArray sources = root.getJSONArray("sources");
                    for (int i=0;i<sources.length();i++) {
                        JSONObject sourcesJSONObject = sources.getJSONObject(i);
                        Source source = new Source();
                        source.id=sourcesJSONObject.getString("id");
                        source.name=sourcesJSONObject.getString("name");
                        sourceHashMap.put(source.id,source.name);
                        //resultArticle.add(article);
                    }
                }
            } catch (Exception e) {
                //Handle Exceptions
            } finally {
                //Close the connections
            }
            return sourceHashMap;


            //return null;
        }
    }




}

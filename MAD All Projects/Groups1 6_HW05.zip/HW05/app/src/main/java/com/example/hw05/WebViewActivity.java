package com.example.hw05;
/*
 * Assignment- HW05
 * File Name- WebViewActivity.java
 * Groups1 6- Siddharth Panda, Nayana Naik*/
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WebViewActivity extends AppCompatActivity {

    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);

        webView=(WebView)findViewById(R.id.webview_news);
        Intent fromNews=getIntent();
        Bundle getBundle=getIntent().getExtras();
        String url=getBundle.getString("clickedNewsItem");
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl(url);

    }
}

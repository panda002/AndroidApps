package com.example.hw05;
/*
 * Assignment- HW05
 * File Name- News.java
 * Groups1 6- Siddharth Panda, Nayana Naik*/
import androidx.annotation.NonNull;

public class News {

    String url, urlToImage, title, author, publishedAt;

    public News(){

    }



    @NonNull
    @Override
    public String toString() {


        return url+" "+urlToImage+" "+title+" "+author+" "+publishedAt;
    }
}

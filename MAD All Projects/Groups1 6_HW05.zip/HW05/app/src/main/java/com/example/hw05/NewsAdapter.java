package com.example.hw05;
/*
 * Assignment- HW05
 * File Name- NewsAdapter.java
 * Groups1 6- Siddharth Panda, Nayana Naik*/
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.squareup.picasso.Picasso;

import java.util.List;

public class NewsAdapter extends ArrayAdapter<News> {


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //return super.getView(position, convertView, parent);
        News content=getItem(position);
        ViewHolder viewHolder;
        if(convertView==null){
            convertView= LayoutInflater.from(getContext()).inflate(R.layout.news_item,parent,false);
            viewHolder=new ViewHolder();
            viewHolder.tv_news_title=convertView.findViewById(R.id.tv_news_title);
            viewHolder.tv_news_author=convertView.findViewById(R.id.tv_news_author);
            viewHolder.tv_news_date=convertView.findViewById(R.id.tv_published_at_date);
            viewHolder.iv_news_image=convertView.findViewById(R.id.iv_news_pic);
            convertView.setTag(viewHolder);

        }
        else{
            viewHolder=(ViewHolder)convertView.getTag();
        }

//        TextView tv_news_title=convertView.findViewById(R.id.tv_news_title);
//        TextView tv_news_author=convertView.findViewById(R.id.tv_news_author);
//        TextView tv_news_date=convertView.findViewById(R.id.tv_published_at_date);
//        ImageView iv_news_image=convertView.findViewById(R.id.iv_news_pic);

        viewHolder.tv_news_author.setText(content.author);
        viewHolder.tv_news_title.setText(content.title);
        viewHolder.tv_news_date.setText(content.publishedAt);

        Picasso.get()
                .load(content.urlToImage)
                //.placeholder(R.drawable.user_placeholder)
                .error(R.drawable.ic_launcher_background)
                .into(viewHolder.iv_news_image);


        return convertView;
    }
    public static class ViewHolder{
        TextView tv_news_title;
        TextView tv_news_author;
        TextView tv_news_date;
        ImageView iv_news_image;
    }

    public String getNewsItemURL(int position){
        News news=getItem(position);
        return news.url;
    }
    public NewsAdapter(@NonNull Context context, int resource, @NonNull List<News> objects) {
        super(context, resource, objects);


    }
}

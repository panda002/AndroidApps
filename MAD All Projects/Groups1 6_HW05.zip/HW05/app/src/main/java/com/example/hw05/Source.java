package com.example.hw05;
/*
 * Assignment- HW05
 * File Name- Source.java
 * Groups1 6- Siddharth Panda, Nayana Naik*/
import androidx.annotation.NonNull;

public class Source {

    String id, name;

    public Source(){

    }

    public Source(String name){
        this.name=name;
    }

    @NonNull
    @Override
    public String toString() {
        return name;
    }
}

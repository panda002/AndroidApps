package com.ownproj.finalexam;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ShowPlacesRecyclerView extends RecyclerView.Adapter<ShowPlacesRecyclerView.MyViewHolder> {

    private ArrayList<Places> localPlaces;
    private GetCityDetails getCityDetails;

    public ShowPlacesRecyclerView(ArrayList<Places> localPlaces) {
        this.localPlaces = localPlaces;
    }

    @NonNull
    @Override
    public ShowPlacesRecyclerView.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.custom_places, parent, false);
        MyViewHolder myViewHolder = new ShowPlacesRecyclerView.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ShowPlacesRecyclerView.MyViewHolder holder, final int position) {
        final Places tempPlaces = localPlaces.get(position);
        holder.tv_placeName.setText(tempPlaces.getPlacename());
        Log.d("TAG", "onBindViewHolder: "+tempPlaces);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                localPlaces.add(tempPlaces);
            }
        });
    }

    @Override
    public int getItemCount() {
        return localPlaces.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private final Context context;

        TextView tv_placeName;

        public MyViewHolder(@NonNull final View itemView) {
            super(itemView);
            context = itemView.getContext();
            tv_placeName = itemView.findViewById(R.id.tv_placeName);

        }
    }

    public interface GetCityDetails {
        void getCityDetails(Places places);
    }
}
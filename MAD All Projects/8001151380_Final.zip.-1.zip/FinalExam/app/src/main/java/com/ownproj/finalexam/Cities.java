package com.ownproj.finalexam;

public class Cities {

    String city;

    public Cities(String city) {
        this.city = city;
    }

    public Cities() {
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @Override
    public String toString() {
        return "Cities{" +
                ", city='" + city + '\'' +
                '}';
    }
}

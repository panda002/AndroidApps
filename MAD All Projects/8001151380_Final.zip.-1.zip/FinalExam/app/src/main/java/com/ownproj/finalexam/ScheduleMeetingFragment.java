package com.ownproj.finalexam;


import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Calendar;


/**
 * A simple {@link Fragment} subclass.
 */
public class ScheduleMeetingFragment extends Fragment implements View.OnClickListener, ShowPlacesRecyclerView.GetCityDetails {

    private EditText title;
    private Button btn_addplace, btn_save;
    private Button btnDatePicker, btnTimePicker;
    private TextView txtDate, txtTime, tv_place;
    private int mYear, mMonth, mDay, mHour, mMinute;
    private OnFragmentInteractionListener mListener;
private String date, time, place, title1;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    public ScheduleMeetingFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_schedule_meeting, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {

        //Date and Time picker
        super.onActivityCreated(savedInstanceState);
        btnDatePicker = getActivity().findViewById(R.id.btn_setdate);
        btnTimePicker = getActivity().findViewById(R.id.btn_settime);
        btn_save = getActivity().findViewById(R.id.btn_save);
        btn_addplace = getActivity().findViewById(R.id.btn_place);
        txtDate = getActivity().findViewById(R.id.in_date);
        txtTime = getActivity().findViewById(R.id.in_time);
        tv_place = getActivity().findViewById(R.id.tv_place);
        title = getActivity().findViewById(R.id.et_title);



        btnDatePicker.setOnClickListener((View.OnClickListener) this);

        btnTimePicker.setOnClickListener((View.OnClickListener) this);

        btn_addplace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getFragmentManager().beginTransaction()
                        .replace(R.id.container, new AddPlaceFragment(), "tag_addplace")
                        .addToBackStack(null)
                        .commit();
            }
        });

        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            date = txtDate.getText().toString();
            time = txtTime.getText().toString();
            place = tv_place.getText().toString();
            title1 = title.getText().toString();

            Meetings meetings = new Meetings();
            meetings.setDate(date);
            meetings.setPlace(place);
            meetings.setTime(time);
            meetings.setTitle(title1);

                if (title.getText().toString().equals("")) {
                    title.setError("First Name is required.");
                }
            else{
            db.collection("Meetings")
                    .document(date)
                    .set(meetings)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    Toast.makeText(getActivity(), "Data is Saved", Toast.LENGTH_SHORT).show();
                }
            });
                }

            }
        });
    }

    @Override
    public void onClick(View v) {

        if (v == btnDatePicker) {

            // Get Current Date
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);


            DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(),
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {
                            btnDatePicker.setVisibility(View.INVISIBLE);
                            txtDate.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if (v == btnTimePicker) {

            // Get Current Time
            final Calendar c = Calendar.getInstance();
            mHour = c.get(Calendar.HOUR_OF_DAY);
            mMinute = c.get(Calendar.MINUTE);

            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(getContext(),
                    new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {
                            btnTimePicker.setVisibility(View.INVISIBLE);
                            txtTime.setText(hourOfDay + ":" + minute);
                        }
                    }, mHour, mMinute, false);
            timePickerDialog.show();
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof ScheduleMeetingFragment.OnFragmentInteractionListener) {
            mListener = (ScheduleMeetingFragment.OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void getCityDetails(Places places) {
        getFragmentManager().beginTransaction()
                .replace(R.id.container, this, "tag_schedulemeeting")
                .addToBackStack(null)
                .commit();
    }


    public interface OnFragmentInteractionListener {
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message message) {
            if(message.what == 200){
                mAdapter.notifyDataSetChanged();
            }
        }
    };
}

package com.ownproj.finalexam;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.ownproj.finalexam.Meetings;

public class ShowMeetingsRecyclerView extends RecyclerView.Adapter<ShowMeetingsRecyclerView.MyViewHolder> {

    // TODO : Initiate your ArrayList which will be used by Recycler View to display Elements
    private ArrayList<Meetings> localMeetings;

    public ShowMeetingsRecyclerView(ArrayList<Meetings> localMeetings) {
        this.localMeetings = localMeetings;
    }

    @NonNull
    @Override
    public ShowMeetingsRecyclerView.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // TODO : Change custom_places with your Recycler View Layout XML
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.custom_all_meetings, parent, false);
        MyViewHolder myViewHolder = new ShowMeetingsRecyclerView.MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ShowMeetingsRecyclerView.MyViewHolder holder, final int position) {
        final Meetings tempMeetings = localMeetings.get(position);
        // TODO : To Generate Element Click Listner use the following code
        // holder.itemView.setOnClickListner(new View.setOnClickListner) (Use IDE Auto complete for this)
    }

    @Override
    public int getItemCount() {
        return localMeetings.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        private final Context context;

        // TODO : Initialize your View Elements

        TextView tv_title;
        TextView tv_place;
        TextView tv_time;
        TextView tv_date;

        public MyViewHolder(@NonNull final View itemView) {
            super(itemView);
            context = itemView.getContext();

            tv_title = itemView.findViewById(R.id.tv_title);
            tv_place = itemView.findViewById(R.id.tv_place);
            tv_time = itemView.findViewById(R.id.tv_datetime);

        }
    }
}
package com.ownproj.finalexam;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity implements ScheduleMeetingFragment.OnFragmentInteractionListener,AddPlaceFragment.OnFragmentInteractionListener {

   //private FirebaseFirestore db = FirebaseFirestore.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ScheduleMeetingFragment  scheduleMeetingFragment = new ScheduleMeetingFragment();
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container, scheduleMeetingFragment, "tag_DisplayHome")
                .addToBackStack(null)
                .commit();
    }
}

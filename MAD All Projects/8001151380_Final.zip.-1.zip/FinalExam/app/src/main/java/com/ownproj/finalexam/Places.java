package com.ownproj.finalexam;

public class Places {

    String placename;

    public String getPlacename() {
        return placename;
    }

    public void setPlacename(String placename) {
        this.placename = placename;
    }

    public Places() {
    }

    @Override
    public String toString() {
        return "Places{" +
                "placename='" + placename + '\'' +
                '}';
    }
}

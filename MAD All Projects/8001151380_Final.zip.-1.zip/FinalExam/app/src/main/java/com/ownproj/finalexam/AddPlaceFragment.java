package com.ownproj.finalexam;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.squareup.okhttp.HttpUrl;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class AddPlaceFragment extends Fragment  {
    private String AUTOCOMPLETE_API = "https://maps.googleapis.com/maps/api/place/autocomplete/json";
    private String PLACES_API = "https://maps.googleapis.com/maps/api/place/details/json";
    private EditText place;
    private Button btn_go;
    private String apiKey;
    private OnFragmentInteractionListener mListener;
    OkHttpClient client = new OkHttpClient();

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    private ArrayList<Places> tempPlaces;

    public AddPlaceFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_place, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        place = getActivity().findViewById(R.id.et_places);
        btn_go = getActivity().findViewById(R.id.bt_go);
        recyclerView = getActivity().findViewById(R.id.rv_getplaces);

        recyclerView.setHasFixedSize(true);
        tempPlaces = new ArrayList<>();
// use a linear layout manager
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);

        mAdapter = new ShowPlacesRecyclerView(tempPlaces);

        recyclerView.setAdapter(mAdapter);

        apiKey = getActivity().getResources().getString(R.string.api_key);


        btn_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                HttpUrl.Builder urlBuilder = HttpUrl.parse(AUTOCOMPLETE_API).newBuilder();
                urlBuilder.addQueryParameter("key", apiKey);
                urlBuilder.addQueryParameter("input", place.getText().toString());
                String url = urlBuilder.build().toString();

                Request request = new Request.Builder()
                        .url(url)
                        .build();

                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(Call call, final Response response) throws IOException {
                        if (!response.isSuccessful()) {
                            throw new IOException("Unexpected code " + response);
                        } else {
                            jsonParse(response.body().string());
                        }
                    }
                });
            }
        });

    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    public interface OnFragmentInteractionListener {
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    private void jsonParse(String jsonString) {
        try {
            JSONObject jObject = new JSONObject(jsonString);
            Log.d("TAG", "jsonParse: "+jsonString);
            JSONArray predictionArray = jObject.getJSONArray("predictions");

            for(int i = 0; i < predictionArray.length(); i++){
                Places temp = new Places();
                JSONObject dataObject = predictionArray.getJSONObject(i);
                temp.setPlacename(dataObject.getString("description"));
                tempPlaces.add(temp);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        Message message = mHandler.obtainMessage(200, "Update List");
        message.sendToTarget();
    }


    Handler mHandler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message message) {
            if(message.what == 200){
                mAdapter.notifyDataSetChanged();
            }
        }
    };
}

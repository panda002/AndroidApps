package com.ownproj.studentprofile;

import android.os.Bundle;


//Sidharth and  Nayana - HW06_Groups1_6
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity implements MyProfile.onFragmentSelectAvatarlistener,
        DisplayMyProfile.OnFragmentProfileEditListener,SelectAvatar.OnFragmentUpdateimageListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportFragmentManager().beginTransaction()
                .add(R.id.container, new MyProfile(),"tag_MyProfile")
                .commit();
    }

    @Override
    public void selectavatar() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, new SelectAvatar(),"tag_SelectAvatar")
                .addToBackStack(null)
                .commit();

    }

    @Override
    public void diplayprofile(Bundle bundle) {

        DisplayMyProfile displayMyProfile = new DisplayMyProfile();
        displayMyProfile.setArguments(bundle);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, displayMyProfile,"tag_DisplayProfile")
                .addToBackStack("tag_MyProfile")
                .commit();
    }

    @Override
    public void updateimage(int i) {
        MyProfile myProfile = (MyProfile) getSupportFragmentManager()
                .findFragmentByTag("tag_MyProfile");
        Bundle bundle= new Bundle();
        bundle.putInt("selectedimage",i);
        myProfile.setArguments(bundle);

    }

    @Override
    public void Oneditclicked(Bundle bundle) {
        MyProfile myProfile=(MyProfile)getSupportFragmentManager()
                .findFragmentByTag("tag_MyProfile");
        myProfile.setArguments(bundle);
    }
}

package com.ownproj.studentprofile;


import android.content.Context;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class DisplayMyProfile extends Fragment {

    private OnFragmentProfileEditListener listener;
/*    TextView fullname;
    TextView departmentname;
    TextView studentid;
    ImageView avatarimage;*/
    Bundle bundle;

    public DisplayMyProfile() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        listener = (OnFragmentProfileEditListener) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_display_my_profile, container, false);


        bundle = this.getArguments();
        String fname = bundle.getString("First");
        String lname = bundle.getString("Last");
        String stid = bundle.get("StID")+"";
        //String name = fname;
        String name = fname.concat(" "+lname);

        TextView fullname = view.findViewById(R.id.tv_fragDisplayName);
        TextView departmentname = view.findViewById(R.id.tv_fragDisplayDepartment);
        TextView studentid = view.findViewById(R.id.tv_fragDisplayStudentId);
        ImageView avatarimage = view.findViewById(R.id.imageFragDisplayProfile);

        if (bundle != null) {
        fullname.setText(name);
        departmentname.setText(bundle.get("Dep")+"");
        studentid.setText(stid);

        int selectedimage = bundle.getInt("selectedimage");

            if(selectedimage==1)
            {
                avatarimage.setImageResource(R.drawable.avatar_f_1);
            }
            else if(selectedimage==2)
            {
                avatarimage.setImageResource(R.drawable.avatar_m_1);
            }
            else  if(selectedimage==3)
            {
                avatarimage.setImageResource(R.drawable.avatar_f_2);
            }
            else if(selectedimage==4)
            {
                avatarimage.setImageResource(R.drawable.avatar_m_2);
            }
            else  if(selectedimage==5)
            {
                avatarimage.setImageResource(R.drawable.avatar_f_3);
            }
            else if(selectedimage==6)
            {
                avatarimage.setImageResource(R.drawable.avatar_m_3);
            }

        }

            Button editbutton = view.findViewById(R.id.bt_edit);
            editbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.Oneditclicked(bundle);
                    getActivity().getSupportFragmentManager().popBackStack();
                }
            });

            return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
/*        bundle = this.getArguments();
        Button editbutton = getActivity().findViewById(R.id.bt_edit);
        editbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.Oneditclicked(bundle);
            }
        })*/;
    }

    public interface onFragmentprofile{
        void myprofile();
    }

    @Override
    public void onStart() {
        super.onStart();

    }

    public interface OnFragmentProfileEditListener {
        // TODO: Update argument type and name
        void Oneditclicked(Bundle bundle);

    }
}

package com.ownproj.studentprofile;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class MyProfile extends Fragment {

    private onFragmentSelectAvatarlistener mListener;
    //String department;
/*    EditText fname;
    EditText lname;
    EditText sid;*/
    int i=0;
    ImageView avatar;
    //String department;



    public MyProfile() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view =  inflater.inflate(R.layout.fragment_my_profile, container, false);
        getActivity().setTitle("My Profile");
        avatar = view.findViewById(R.id.iv_selectavatar);

        Bundle args = getArguments();

        if(args!=null) {

            i = args.getInt("selectedimage", 0);

            if (i == 1) {
                avatar.setImageResource(R.drawable.avatar_f_1);
            }
            else  if(i==2)
            {
                avatar.setImageResource(R.drawable.avatar_m_1);
            }
            else  if(i==3)
            {
                avatar.setImageResource(R.drawable.avatar_f_2);
            }
            else  if(i==4)
            {
                avatar.setImageResource(R.drawable.avatar_m_2);
            }
            else  if(i==5)
            {
                avatar.setImageResource(R.drawable.avatar_f_3);
            }
            else  if(i==6)
            {
                avatar.setImageResource(R.drawable.avatar_m_3);
            }
        }

        avatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.selectavatar();
            }
        });

        Button button = view.findViewById(R.id.bt_save);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText fname = getView().findViewById(R.id.et_firstname);
                EditText lname = getView().findViewById(R.id.et_lastname);
                EditText sid = getView().findViewById(R.id.et_studentid);

        RadioGroup radioGroup = getView().findViewById(R.id.radio_department);
        int selectedId=radioGroup.getCheckedRadioButtonId();
        //String department = String.valueOf(getView().findViewById(selectedId));
        String department = ((RadioButton)getView().findViewById(radioGroup.getCheckedRadioButtonId())).getText().toString();

         radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup radioGroup, int i) {
                        Log.d("Demo", i+" dep selected");


                    if(i==R.id.rd_cs)
                    {
                        //department = (RadioButton);
                        Log.d("Demo ", i+" department selected");
                    }
                    }
                });
                //String studentid = view.findViewById(R.id.et_studentid).toString();

                if (fname.getText() == null)
                {
                    fname.setError("Please enter the first name");
                } else if (lname.getText() == null)
                {
                    lname.setError("Please enter the last name");
                } else if (sid.getText() == null || sid.getText().length() != 9)
                {
                    sid.setError("Enter 9 digit ID");
                } else {
                   Bundle bundle = new Bundle();
                    bundle.putString("First", fname.getText().toString());
                    bundle.putString("Last", lname.getText().toString());
                    bundle.putInt("StID", Integer.parseInt(String.valueOf(sid.getText())));
                    bundle.putString("Dep", department);
                    bundle.putInt("selectedimage", i);

                    mListener.diplayprofile(bundle);
                }
            }
        });


        return view;

    }



    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //fname = getActivity().findViewById(R.id.tv_fragDisplayName);
        avatar = getActivity().findViewById(R.id.iv_selectavatar);
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        mListener = (onFragmentSelectAvatarlistener) getActivity();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }
    public interface onFragmentSelectAvatarlistener{
        void selectavatar();
        void diplayprofile(Bundle bundle);
    }


}

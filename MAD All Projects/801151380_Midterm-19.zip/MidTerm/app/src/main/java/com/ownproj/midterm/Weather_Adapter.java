package com.ownproj.midterm;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class Weather_Adapter extends ArrayAdapter<Weather> {
    Context context;
    ArrayList<Weather> objects;

    public Weather_Adapter(Context context, ArrayList<Weather> objects) {
        super(context, R.layout.fivehourlist, objects);
        this.context = context;
        this.objects = objects;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.fivehourlist, parent, false);
            holder = new ViewHolder();
            holder.thumbnail = (ImageView) convertView.findViewById(R.id.imageViewThumbnail);
            holder.temperature = (TextView) convertView.findViewById(R.id.textViewTemperature);
            convertView.setTag(holder);
        }

        holder = (ViewHolder) convertView.getTag();
        ImageView thumbnail = holder.thumbnail;
        TextView temperature = holder.temperature;

        //Picasso.with(context).load(objects.get(position).getIconUrl()).into(thumbnail);


        return convertView;
    }

    static class ViewHolder {
        ImageView thumbnail;
        TextView time;
        TextView condition;
        TextView temperature;
    }
}
package com.ownproj.midterm;
public class City {

    public City() {

    }

    public String getCity() {
        return city;
    }

    public String getCountry() {
        return country;
    }

    String city, country;

    @Override
    public String toString() {
        return city+","+country;
    }
}

package com.ownproj.midterm;
public class Weather {

    String temp;
    String tempmax;
    String tempmin;
    String description;
    String humidity;
    String windspeed;

    public Weather() {
    }

    public String getTemp() {
        return temp;
    }

    public String getTempmax() {
        return tempmax;
    }

    public String getTempmin() {
        return tempmin;
    }

    public String getDescription() {
        return description;
    }

    public String getHumidity() {
        return humidity;
    }

    public String getWindspeed() {
        return windspeed;
    }

    @Override
    public String toString() {
        return temp+","+tempmax+","+                    tempmin+","+
                    description+","+
                    humidity+","+
                    windspeed;
    }
}

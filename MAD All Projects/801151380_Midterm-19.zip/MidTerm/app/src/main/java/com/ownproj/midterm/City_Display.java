package com.ownproj.midterm;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class City_Display extends AppCompatActivity {

    private TextView city;
    private TextView temp;
    private TextView tempmax;
    private TextView tempmin;
    private TextView description;
    private TextView humidity;
    private TextView windspeed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city__display);
        setTitle("Current Weather");

        city = findViewById(R.id.city_country);
        temp = findViewById(R.id.tv_temp);
        tempmax = findViewById(R.id.tv_tempmax);
        tempmin = findViewById(R.id.tv_tempmin);
        description = findViewById(R.id.tv_description);
        humidity = findViewById(R.id.tv_humidity);
        windspeed = findViewById(R.id.tv_windspeed);
        Bundle getBundle = getIntent().getExtras();
        ArrayList result = (ArrayList) getBundle.getSerializable("sourceHashMap");
        String value = getBundle.getString("clickedItem");
        city.setText(value);


            new GetDataAsync().execute("https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=579d349710d0b9eb0e9ce3efc0f6c92c");

    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    private class GetDataAsync extends AsyncTask<String, Void, ArrayList<Weather>> {

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected ArrayList<Weather> doInBackground(String... params) {
            HttpURLConnection connection = null;
            ArrayList<Weather> weatherresult = new ArrayList<>();
            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    String json = IOUtils.toString(connection.getInputStream(), "UTF8");

                    JSONObject root = new JSONObject(json);
                    JSONArray weathers = root.getJSONArray("weather");
                    JSONObject bodyResult= weathers.getJSONObject(Integer.parseInt("body"));
                    JSONArray weatherarr=bodyResult.getJSONArray("main");

                    for (int i = 0; i < weatherarr.length(); i++) {
                        JSONObject sourceJson = weatherarr.getJSONObject(i);
                        Weather w1 = new Weather();
                        w1.temp = sourceJson.getString("temp");
                        w1.description = sourceJson.getString("description");
                        w1.humidity = sourceJson.getString("humidity");
                        w1.tempmax = sourceJson.getString("tempmax");
                        w1.tempmin = sourceJson.getString("tempmin");
                        w1.windspeed = sourceJson.getString("windspeed");
                        weatherresult.add(w1);

                    }
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                //Log.e(TAG, "doInBackground: ", e);
            } catch (JSONException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
            return weatherresult;

        }

    }
    protected void onPostExecute(final ArrayList<Weather> result) {
        List valueArrayList = new ArrayList();
        Weather weather= new Weather();
        temp.setText(weather.getTemp());
        tempmax.setText(weather.getTempmax());
        tempmin.setText(weather.getTempmin());
        humidity.setText(weather.getHumidity());
        windspeed.setText(weather.getWindspeed());
        description.setText(weather.getDescription());

    }

}

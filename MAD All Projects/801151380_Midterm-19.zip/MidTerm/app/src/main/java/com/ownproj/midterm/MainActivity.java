package com.ownproj.midterm;

import androidx.appcompat.app.AppCompatActivity;


///Sidharth Panda

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.xml.transform.Source;

public class MainActivity extends AppCompatActivity {
    ListView mylistview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

                if(isConnected()){
                    Toast.makeText(MainActivity.this, "Internet Present", Toast.LENGTH_SHORT).show();
                    //new GetDataAsync().execute("");

                } else{
                    Toast.makeText(MainActivity.this, "No Internet", Toast.LENGTH_SHORT).show();
                }

        mylistview = findViewById(R.id.list_view);



        String json = null;
        {

            InputStream is = getResources().openRawResource(R.raw.cities);
            int size = 0;
            try {
                size = is.available();
            } catch (IOException e) {
                e.printStackTrace();
            }

            byte[] buffer = new byte[size];

            try {
                is.read(buffer);
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                json = new String(buffer, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            Log.d("JSON", "instance initializer: "+json);
        }

        final ArrayList<City> result = new ArrayList<>();

        try{
        JSONObject root = new JSONObject(json);
        JSONArray track_array=root.getJSONArray("data");
        for(int i=0;i<track_array.length();i++) {
            JSONObject jO = track_array.getJSONObject(i);
            City c = new City();
            c.city = jO.getString("city");
            c.country = jO.getString("country");

            result.add(c);

            Log.d("result", "onCreate: " + result);
        }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        final ArrayAdapter<City> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, result);
        MainActivity.this.mylistview.setAdapter(adapter);

        MainActivity.this.mylistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Bundle bundle = new Bundle();
                Intent intent= new Intent(MainActivity.this, City_Display.class);
                City city = (City) adapterView.getItemAtPosition(i);
                City city2 = (City) adapterView.getItemAtPosition(i);
                bundle.putSerializable("clickedItem",city.getCity()+","+city2.getCountry());
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected() ||
                (networkInfo.getType() != ConnectivityManager.TYPE_WIFI
                        && networkInfo.getType() != ConnectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }






}

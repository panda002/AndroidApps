package com.example.inclass04;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    SeekBar sb_main;
    Button btn_generate;
    TextView tv_seekbar_value;
    TextView tv_avg_value;
    TextView tv_max_value;
    TextView tv_min_value;
    Integer progress;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // sb_main=(SeekBar) findViewById(R.id.sb_main_seekbar);
        //sb_main.setMax(10);
        btn_generate=(Button)findViewById(R.id.btn_generate);
        tv_seekbar_value=(TextView)findViewById(R.id.tv_seekbar_value) ;

    tv_avg_value=(TextView)findViewById(R.id.tv_avg_value);
        sb_main=(SeekBar)findViewById(R.id.sb_main_seekbar);
tv_max_value=(TextView)findViewById(R.id.tv_max_value);
tv_min_value=(TextView)findViewById(R.id.tv_mim_value);
        sb_main.setMax(10);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMax(1);
       // progressDialog.setCancelable(false);
       // progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        sb_main.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                progress=sb_main.getProgress();
                tv_seekbar_value.setText(String.valueOf(progress+" times"));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        btn_generate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                new MyAsyncTask().execute(progress);
                //start heavy work background task
            }
        });
    }

    class MyAsyncTask extends AsyncTask<Integer, Double, ArrayList<Double>>{
        ArrayList<Double> numbersArrayList;
        SeekBar sb_main;
        int progress;
        String averageString;
        String minimumString;
        String maximumString;


        @Override
        protected ArrayList<Double> doInBackground(Integer... integers) {
            numbersArrayList=HeavyWork.getArrayNumbers(integers[0]);
            // progressDialog.show();

            return numbersArrayList;
        }

        @Override
        protected void onPreExecute() {

            progressDialog.show();
        }

        @Override
        protected void onPostExecute(ArrayList<Double> doubles) {

            Double maximum, minimum, average, sum=0.0;
            for(int i=0;i<doubles.size();i++){
                sum+=doubles.get(i);
            }
            average=(Double)sum/doubles.size();
            tv_avg_value.setText(String.valueOf(average));
            Collections.sort(doubles);
            minimum=(Double)doubles.get(0);
            tv_min_value.setText(String.valueOf(minimum));
            maximum=(Double)doubles.get(doubles.size()-1);
            tv_max_value.setText(String.valueOf(maximum));
            progressDialog.dismiss();

        }
    }
}



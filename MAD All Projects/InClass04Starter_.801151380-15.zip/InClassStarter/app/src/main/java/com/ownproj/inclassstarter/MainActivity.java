package com.ownproj.inclassstarter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    public static final String ADD = "add";
    public static final String SUB = "sub";
    TextView tv_result;
    Button bt_add;
    Button bt_sub;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_result = findViewById(R.id.tv_result);
        bt_add = findViewById(R.id.bt_add);
        bt_sub = findViewById(R.id.subtract);


        bt_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String addselected;
                Intent intent = new Intent(MainActivity.this, CalculationActivity.class);
                Bundle sendData = new Bundle();
                CalculationActivity calculationActivity = new CalculationActivity();
                intent.putExtra("ADD","Adding");
                startActivity(intent);
            }
        });




    }
}

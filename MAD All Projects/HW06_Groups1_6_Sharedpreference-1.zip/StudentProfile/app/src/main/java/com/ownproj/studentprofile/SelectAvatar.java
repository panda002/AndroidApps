package com.ownproj.studentprofile;


import android.content.Context;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ImageView;


/**
 * A simple {@link Fragment} subclass.
 */
public class SelectAvatar extends Fragment implements View.OnClickListener{

    private OnFragmentUpdateimageListener mListener;
/*    ImageView avatar1;
    ImageView avatar2;
    ImageView avatar3;
    ImageView avatar4;
    ImageView avatar5;
    ImageView avatar6;*/

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mListener = (OnFragmentUpdateimageListener) context;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

/*
        avatar1 = getActivity().findViewById(R.id.avatar_f_1);
        avatar2 = getActivity().findViewById(R.id.avatar_m_1);
        avatar3 = getActivity().findViewById(R.id.avatar_f_2);
        avatar4 = getActivity().findViewById(R.id.avatar_m_2);
        avatar5 = getActivity().findViewById(R.id.avatar_f_3);
        avatar6 = getActivity().findViewById(R.id.avatar_m_3);
*/

        GridLayout gl = getView().findViewById(R.id.gridlayout);
        int childcount = gl.getChildCount();


        for(int i = 0; i < childcount; i++){
            gl.getChildAt(i).setOnClickListener(this);
        }

        getActivity().setTitle("Select Avatar");

    }/*
        avatar1.setOnClickListener(this);
    *//*.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mListener.updateimage(1);
                getActivity().getSupportFragmentManager().popBackStack();


            }
        });*//*
        avatar2.setOnClickListener(this);
                *//*.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mListener.updateimage(2);
                getActivity().getSupportFragmentManager().popBackStack();


            }
        });*//*
        avatar3.setOnClickListener(this);
        *//*.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mListener.updateimage(3);
                getActivity().getSupportFragmentManager().popBackStack();


            }
        });*//*
        avatar4.setOnClickListener(this);
    *//*.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mListener.updateimage(4);
                getActivity().getSupportFragmentManager().popBackStack();


            }
        });*//*
        avatar5.setOnClickListener(this);
                *//*.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mListener.updateimage(5);
                getActivity().getSupportFragmentManager().popBackStack();


            }
        });*//*
        avatar6.setOnClickListener(this);
                *//*new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //mListener.updateimage(6);
                getActivity().getSupportFragmentManager().popBackStack();


            }
        });*//*
    }*/

    @Override
    public void onClick(View v) {
        mListener.onFragmentInteraction(v);
    }

    public SelectAvatar() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_select_avatar, container, false);
        getActivity().setTitle("Select Avatar");
        return view;
    }
    public interface OnFragmentUpdateimageListener {
        // TODO: Update argument type and name
        //void updateimage(int i);
        void onFragmentInteraction(View v);
    }




}

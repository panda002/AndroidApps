package com.ownproj.studentprofile;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 */
public class MyProfile extends Fragment  implements View.OnClickListener{

    private onFragmentSelectAvatarlistener mListener;
    //ImageView avatar;
    Profile profile;
    Gson gson = new Gson();
    RadioGroup radio_department;
    String selectedimageresource = "";



    public MyProfile() {
        // Required empty public constructor
    }

    void setcomponents(SharedPreferences sharedPreferences){
        profile = gson.fromJson(sharedPreferences
                .getString("profileinfolist",""), Profile.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_my_profile, container, false);
        getActivity().setTitle("My Profile");

        return view;
    }


    static HashMap<String,Integer> map = new HashMap<String, Integer>(){{
        put("f1", R.drawable.avatar_f_1);
        put("m1", R.drawable.avatar_m_1);
        put("f2", R.drawable.avatar_f_2);
        put("m2", R.drawable.avatar_m_2);
        put("f3", R.drawable.avatar_f_3);
        put("m3", R.drawable.avatar_m_3);
    }};


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // getActivity().getActionBar().setTitle("My Profile");
        if(!selectedimageresource.equals("") && map.get(selectedimageresource) != null) {
            ((ImageView) view.findViewById(R.id.iv_selectavatar)).setImageResource(map.get(selectedimageresource));
        }

        if(MainActivity.isSharedPreference){

            for(String key: map.keySet()) {
                if(map.get(key).equals(profile.imageno)) {
                    selectedimageresource = key;
                }
            }

            ((EditText) view.findViewById(R.id.et_firstname)).setText(profile.fname);
            ((EditText) view.findViewById(R.id.et_lastname)).setText(profile.lname);
            ((EditText) view.findViewById(R.id.et_studentid)).setText(String.valueOf(profile.studentId));

            ((RadioGroup) view.findViewById(R.id.radio_department)).check(profile.department);
            ((ImageView) view.findViewById(R.id.iv_selectavatar)).setImageResource(profile.imageno);

            MainActivity.isSharedPreference = false;

        }

        view.findViewById(R.id.iv_selectavatar).setOnClickListener((View.OnClickListener) this);
        view.findViewById(R.id.bt_save).setOnClickListener((View.OnClickListener) this);

        getActivity().setTitle("My Profile");

    }

    public void onClick(View v) {
        if(v.getId() == R.id.bt_save){
            EditText fname = getView().findViewById(R.id.et_firstname);
            EditText lname = getView().findViewById(R.id.et_lastname);
            EditText sid = getView().findViewById(R.id.et_studentid);
            radio_department = getView().findViewById(R.id.radio_department);



            if (fname.getText() == null)
            {
                fname.setError("Please enter the first name");
                return;
            } else if (lname.getText() == null)
            {
                lname.setError("Please enter the last name");
                return;
            } else if (sid.getText() == null || sid.getText().length() != 9)
            {
                sid.setError("Enter 9 digit ID");
                return;
            }else if(selectedimageresource.equals("")){
                Toast.makeText(getContext(), "Select a Avatar", Toast.LENGTH_SHORT).show();
                return;
            }

            profile = new Profile(fname.getText()
                    .toString(), lname.getText()
                    .toString(), Integer.valueOf(sid.getText().toString()), radio_department.getCheckedRadioButtonId(), map.get(selectedimageresource));
            Log.d("Profile", "onClick: "+profile.fname+" "+profile.department+" "+profile.studentId);
            mListener.diplayprofile(profile);
        }
        else {
            mListener.onFragmentInteraction(v);
        }
    }



/*    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //fname = getActivity().findViewById(R.id.tv_fragDisplayName);
        avatar = getActivity().findViewById(R.id.iv_selectavatar);
    }*/


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        mListener = (onFragmentSelectAvatarlistener) getActivity();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }
    public interface onFragmentSelectAvatarlistener{
        //void selectavatar();
        void diplayprofile(Profile profile);
        void onFragmentInteraction(View v);
    }


}

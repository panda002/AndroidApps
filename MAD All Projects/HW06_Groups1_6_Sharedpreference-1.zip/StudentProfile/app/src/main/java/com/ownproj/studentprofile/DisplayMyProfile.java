package com.ownproj.studentprofile;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;

import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 */
public class DisplayMyProfile extends Fragment {

    private OnFragmentProfileEditListener listener;
    /*    TextView fullname;
        String  departmentname;
        TextView studentid;
        ImageView avatarimage;*/
    String departmentname;
    //Bundle bundle;


    Gson gson = new Gson();
    Profile profileinfo;
    private View avatarView;

    public DisplayMyProfile() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        listener = (OnFragmentProfileEditListener) context;

    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_display_my_profile, container, false);

        return view;
    }

    void setcomponents(SharedPreferences sharedPreferences) {
        profileinfo = gson.fromJson(sharedPreferences.getString("profileinfolist", ""), Profile.class);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

/*         HashMap<Integer,Integer> map = new HashMap<Integer, Integer>(){{
            put(1, R.drawable.avatar_f_1);
            put(2, R.drawable.avatar_m_1);
            put(3, R.drawable.avatar_f_2);
            put(4, R.drawable.avatar_m_2);
            put(5, R.drawable.avatar_f_3);
            put(6, R.drawable.avatar_m_3);
        }};*/

        Log.d("TAG", "onViewCreated: ");
        if (profileinfo == null) {
            ((MainActivity)getActivity()).updateFragment(1);
        }
        else {
            //avatarView = view.findViewById(R.id.iv_selectavatar);
            ((ImageView) getView().findViewById(R.id.imageFragDisplayProfile)).setImageResource(profileinfo.imageno);
            ((TextView) getView().findViewById(R.id.tv_fragDisplayName)).setText(profileinfo.fname + " " + profileinfo.lname);
            ((TextView) getView().findViewById(R.id.tv_fragDisplayStudentId)).setText(String.valueOf(profileinfo.studentId));

            if (profileinfo.department == R.id.rd_cs)
                departmentname = "CS";
            else if (profileinfo.department == R.id.rd_sis)
                departmentname = "SIS";
            else if (profileinfo.department == R.id.rd_bio)
                departmentname = "BIO";
            else
                departmentname = "Other";


            ((TextView) getView()
                    .findViewById(R.id.tv_fragDisplayDepartment))
                    .setText(departmentname);

            view.findViewById(R.id.bt_edit).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    listener.Oneditclicked();
                }
            });
        }

        getActivity().setTitle("Display My Profile");
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
/*        bundle = this.getArguments();
        Button editbutton = getActivity().findViewById(R.id.bt_edit);
        editbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.Oneditclicked(bundle);
            }
        })*/
        ;
    }

/*    public interface onFragmentprofile{
        void myprofile();
    }*/

/*    @Override
    public void onStart() {
        super.onStart();

    }*/

    public interface OnFragmentProfileEditListener {
        // TODO: Update argument type and name
        void Oneditclicked();


    }
}

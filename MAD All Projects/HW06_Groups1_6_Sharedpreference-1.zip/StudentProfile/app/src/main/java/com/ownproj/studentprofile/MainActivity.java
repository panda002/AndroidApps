package com.ownproj.studentprofile;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

//Sidharth and Nayana - Group1-6
public class MainActivity extends AppCompatActivity implements MyProfile.onFragmentSelectAvatarlistener,
        DisplayMyProfile.OnFragmentProfileEditListener, SelectAvatar.OnFragmentUpdateimageListener {


    String profileinfolist;
    Gson gson = new Gson();
    Context context;
    SharedPreferences sharedPreferences;
    MyProfile myProfile = new MyProfile();
    static Boolean isSharedPreference = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = getApplicationContext();
        sharedPreferences = context.getSharedPreferences("profileinfo", MODE_PRIVATE);
        if (sharedPreferences.getString("profileinfolist", "").equals("")) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .add(R.id.container, new MyProfile(), "tag_MyProfile")
                    .commit();
        } else {
            DisplayMyProfile displayMyProfile = new DisplayMyProfile();
            isSharedPreference = true;
            displayMyProfile.setcomponents(sharedPreferences);
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.container, displayMyProfile, "tag_DisplayProfile")
                    .addToBackStack("tag_MyProfile")
                    .commit();
        }
    }

    @Override
    public void onFragmentInteraction(View v) {
        switch (v.getId()) {
            case R.id.iv_selectavatar:
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.container, new SelectAvatar(), "tag_SelectAvatar")
                        .addToBackStack(null)
                        .commit();
                break;
            case R.id.f1:
            case R.id.m1:
            case R.id.f2:
            case R.id.m2:
            case R.id.f3:
            case R.id.m3:
                ImageView ig = (ImageView) v;
                myProfile = (MyProfile) getSupportFragmentManager()
                        .findFragmentByTag("tag_MyProfile");
                myProfile.selectedimageresource = (String) ig.getTag();
                getSupportFragmentManager().popBackStack();
                break;

        }

    }

/*    @Override
    public void selectavatar() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, new SelectAvatar(), "tag_SelectAvatar")
                .addToBackStack(null)
                .commit();

    }*/

    @Override
    public void diplayprofile(Profile profile) {

        DisplayMyProfile displayMyProfile = new DisplayMyProfile();
        profileinfolist = gson.toJson(profile);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("profileinfolist", profileinfolist);
        editor.apply();

        displayMyProfile.setcomponents(sharedPreferences);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container, displayMyProfile, "tag_DisplayProfile")
                .addToBackStack(null)
                .commit();
        /*DisplayMyProfile displayMyProfile = new DisplayMyProfile();
        displayMyProfile.setArguments(profile);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, displayMyProfile,"tag_DisplayProfile")
                .addToBackStack("tag_MyProfile")
                .commit();*/
    }


/*    @Override
    public void updateimage(int i) {
        MyProfile myProfile = (MyProfile) getSupportFragmentManager()
                .findFragmentByTag("tag_MyProfile");
        Bundle bundle = new Bundle();
        bundle.putInt("selectedimage", i);
        myProfile.setArguments(bundle);

    }*/

    @Override
    public void Oneditclicked() {


/*        MyProfile myProfile=(MyProfile)getSupportFragmentManager()
                .findFragmentByTag("tag_MyProfile");*/

        if (getSupportFragmentManager().getBackStackEntryCount() == 0) {
            myProfile.setcomponents(sharedPreferences);
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.container, myProfile, "tag_MyProfile")
                    .commit();
        } else {
            getSupportFragmentManager().popBackStack();
        }
    }

    public void updateFragment(int fragmentId) {
        switch (fragmentId) {
            case 1:
                getSupportFragmentManager().beginTransaction().replace(R.id.container, myProfile)
                        .commit();
                break;
        }
    }
}

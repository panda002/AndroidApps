package com.ownproj.studentprofile;

import android.widget.ImageView;

public class Profile {
    String fname;
    String lname;
    int department;
    int studentId;
    int imageno;


    public Profile(String fname, String lname, int department, int studentId, int imageInteger) {
        this.fname = fname;
        this.lname = lname;
        this.department = department;
        this.studentId = studentId;
        this.imageno = imageInteger;
    }

/*    public String getFname() {
        return fname;
    }

    public String getLname() {
        return lname;
    }

    public String getDepartment() {
        return String.valueOf(department);
    }

    public String getStudentId() {
        return studentId;
    }

    public int getImageno() {
        return imageno;
    }*/
}

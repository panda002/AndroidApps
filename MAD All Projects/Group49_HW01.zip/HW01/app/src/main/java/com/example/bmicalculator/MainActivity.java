package com.example.bmicalculator;
/*
*Assignment: HW01
* File Name: MainActivity.java
*Full Name: Sidharth Panda, Nayana Naik
*
*/
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText etWeight=(EditText)findViewById(R.id.editText_weight);
        final EditText etHeightInFeet=(EditText)findViewById(R.id.editText_height_in_feet);
        final EditText etHeightInInch=(EditText)findViewById(R.id.editText_height_in_unit_inch);
        Button btCalculate=(Button)findViewById(R.id.button_calculate);

        final TextView tvCalculatedBMI=(TextView)findViewById(R.id.textView_BMI_calculates);
        final TextView tvResultBMI=(TextView)findViewById(R.id.textView_BMI_Result);

        btCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                boolean isEditTextValid=true;


                if (TextUtils.isEmpty(etWeight.getText())||etWeight.getText().toString().equals("0")) { //Checks if Weight is empty or user has entered zero
                    isEditTextValid = false;
                    etWeight.setError(getText(R.string.error_invalid_input));
                    tvCalculatedBMI.setText("");
                    tvResultBMI.setText("");
                }

                if ((TextUtils.isEmpty(etHeightInFeet.getText())&&TextUtils.isEmpty(etHeightInInch.getText()))||    //Checks if both Heights are empty
                        (etHeightInFeet.getText().toString().equals("0")&&etHeightInInch.getText().toString().equals("0"))|| //Checks if both heights entered by user are zero
                        (etHeightInFeet.getText().toString().equals("0"))||//Checks if user entered zero for Height in Feet
                        (TextUtils.isEmpty(etHeightInInch.getText()))||// Checks condition when height in feet is entered but height in inches is not entered
                        (TextUtils.isEmpty(etHeightInFeet.getText())))
                     {
                    isEditTextValid = false;
                    etHeightInFeet.setError(getText(R.string.error_invalid_input));
                    etHeightInInch.setError(getText(R.string.error_invalid_input));
                    tvCalculatedBMI.setText("");
                    tvResultBMI.setText("");

                }


                //Displays Toast message if any invalid input is present
                if (!isEditTextValid)
                {
                    Toast.makeText(getApplicationContext(),getText(R.string.error_invalid_input),Toast.LENGTH_SHORT).show();

                    //Success
                } else {

                    //Clears setError messages when all inputs are valid
                    etWeight.setError(null);
                    etHeightInFeet.setError(null);
                    etHeightInInch.setError(null);
                    //Display Toast message
                    Toast.makeText(getApplicationContext(),getText(R.string.toast_bmi_calculated),Toast.LENGTH_SHORT).show();
                    //Conversion from String to Double/Integer
                    Double weight=Double.parseDouble(etWeight.getText().toString());
                    Integer heightInFeet=Integer.parseInt(etHeightInFeet.getText().toString());
                    Double heightInInch=Double.parseDouble(etHeightInInch.getText().toString());
                    //Convert feet into inches, add inches to get total height in inches
                    Double totalHeightInInches=(Double)((heightInFeet*12)+heightInInch);
                    //Calculates BMI according to the formula
                    Double calculateBmi=calculateBmi(weight,totalHeightInInches);
                    //Log.d("BMI",calculateBmi.toString());
                    //Shows the calculated numeric result
                    tvCalculatedBMI.setText(getText(R.string.textView_calculated_bmi).toString().concat(calculateBmi.toString()));
                    //Checks for BMI Result (Underweight, Normal Weight, Overweight, Obesity)
                    String resultBMI=resultBmi(calculateBmi);
                    Log.d("Result BMI",resultBMI);
                    //Shows the BMI result
                    tvResultBMI.setText(resultBMI);

                }



            }
        });


    }

    protected Double calculateBmi(Double weight,Double height){
        return (weight/(height*height))*703;
    }

    protected String resultBmi(Double bmi){

        if(bmi <= 18.5){
            return getText(R.string.bmi_result_underweight).toString();
        }
        else if(bmi>=18.5 && bmi <= 24.9){
            return getText(R.string.bmi_result_normal).toString();
        }
        else if(bmi >=25 && bmi <=29.9 ){
            return getText(R.string.bmi_result_overweight).toString();
        }
        else{
            return getText(R.string.bmi_result_obese).toString();
        }

    }





}

package com.example.inclass12;

import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MapLatLong {

    ArrayList<MapLatLong.Point> points = new ArrayList<MapLatLong.Point>();

    public static class Point {
        double latitude;
        double longitude;
    }

    @Override
    public String toString() {
        return "MapLatLong{" +
                "points=" + points +
                '}';
    }

    public LatLng getLatLong(int index){
        return new LatLng(points.get(index).latitude, points.get(index).longitude);
    }

    public ArrayList<LatLng> getList() {
        ArrayList<LatLng> lt = new ArrayList<>();
        for (int i = 0; i < points.size(); i++) {
            lt.add(new LatLng(points.get(i).latitude, points.get(i).longitude) );
        }
        return lt;
    }
}

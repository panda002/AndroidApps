package com.ownproj.hw04;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private TextView tvminimum;
    private TextView tvmaximum;
    private TextView tvaverage;
    private SeekBar seekBar;
    private Button bt_thread;
    private TextView sb_text;
   // ProgressDialog progressDialog;
    ProgressBar progressBar;
    int val;
    Handler handler;
    ExecutorService taskPool;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvminimum = findViewById(R.id.tv_minimum);
        tvmaximum = findViewById(R.id.tv_maximum);
        tvaverage = findViewById(R.id.tv_average);
        seekBar = findViewById(R.id.seekBar);
        bt_thread = findViewById(R.id.bt_thread);
        sb_text = findViewById(R.id.sb_text);
        handler = new Handler(getApplicationContext().getMainLooper());
       // progressDialog = new ProgressDialog(this);

        //progressBar=new ProgressBar(this);
        progressBar=(ProgressBar)findViewById(R.id.progressBar);
        progressBar.setVisibility(View.INVISIBLE);
        //progressBar.setMax(1);
       // progressDialog.setMax(1);

        taskPool = Executors.newFixedThreadPool(2);


        bt_thread.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(val!=0) {
                    taskPool.execute(new DoWork());
                   // progressDialog.show();
                    //progressBar.
                    progressBar.setVisibility(View.VISIBLE);


                }
                else
                    {
                        Toast toast = Toast.makeText(MainActivity.this,"Please select a complexity",Toast.LENGTH_LONG);
                        toast.show();
                    }

            }
        });


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                val = i;
                sb_text.setText(" " + val + " Times");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }

        });


        //class DoWork implements Runnable {

        //static final int calculation_starts = 1;
        //static final int calculation_progress = 1;
        //static final int calculation_end = 1;
    }

        public class DoWork implements Runnable
        {
        public void run() {
            //Message msg = new Message();
            //msg.what = calculation_starts;
            //handler.sendMessage(msg);

            ArrayList<Double> doubles = HeavyWork.getArrayNumbers(val);
            final Double maximum;
            final Double minimum;
            final Double average;
            Double sum=0.0;
            for(int i=0;i<doubles.size();i++){
                sum+=doubles.get(i);
            }
            average = (Double) sum / doubles.size();

            Collections.sort(doubles);
            minimum = (Double) doubles.get(0);

            maximum = (Double) doubles.get(doubles.size() - 1);

            handler.post(new Runnable() {
                @Override
                public void run() {

                    tvaverage.setText(String.valueOf(average));
                    tvminimum.setText(String.valueOf(minimum));
                    tvmaximum.setText(String.valueOf(maximum));
                    progressBar.setVisibility(View.INVISIBLE);
                    //progressDialog.dismiss();
                }
            });
            }
        }
}

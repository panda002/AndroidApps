package com.ownproj.moviedatabase;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Objects;

//Sidharth

public class ByYear_Activity extends AppCompatActivity {


        private TextView tv_title, tv_desc, tv_genre, tv_rating, tv_year, tv_imdb;
        private ImageView iv_prev;
        private ImageView  iv_next;
        private ImageView  iv_last;
        private ImageView   iv_first;
        private Button bt_finsih;
        int i=0;
        private FirebaseFirestore db = FirebaseFirestore.getInstance();
        private ArrayList<Movies> yearlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_by_year_);
        android:setTitle("Movies by Year");
            tv_title=findViewById(R.id.tv_title);
            tv_desc=findViewById(R.id.tv_description);
            tv_rating=findViewById(R.id.tv_rating);
            tv_year=findViewById(R.id.tv_year);
            tv_imdb=findViewById(R.id.tv_Imdb);
            iv_next=findViewById(R.id.iv_next);
            iv_last=findViewById(R.id.iv_last);
            tv_genre=findViewById(R.id.tv_genre);
            bt_finsih=findViewById(R.id.bt_finish);
            iv_first=findViewById(R.id.iv_first);
            iv_prev=findViewById(R.id.iv_prev);


        db.collection("MoviesDatabase")
                .orderBy("myear", Query.Direction.ASCENDING)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            yearlist = new ArrayList<>();
                            for (QueryDocumentSnapshot queryDocumentSnapshot : Objects.requireNonNull(task.getResult())) {
                                Movies getdata = new Movies(queryDocumentSnapshot.getData());
                                yearlist.add(getdata);
                            }
                            showbyyear();
                        }
                    }
                });

    }
    public void showbyyear(){
        final int j = yearlist.size();

        i = 0;
        tv_title.setText(yearlist.get(i).mname);
        tv_desc.setText(yearlist.get(i).mdesc);
        tv_genre.setText(yearlist.get(i).genre);
        tv_rating.setText(String.valueOf(yearlist.get(i).rating));
        tv_year.setText(String.valueOf(yearlist.get(i).myear));
        tv_imdb.setText(yearlist.get(i).mimdb);

        iv_first.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (i == 0) {
                    Toast.makeText(ByYear_Activity.this, "First movie", Toast.LENGTH_SHORT).show();
                } else {
                    i = 0;

                    tv_title.setText(yearlist.get(i).mname);
                    tv_desc.setText(yearlist.get(i).mdesc);
                    tv_genre.setText(yearlist.get(i).genre);
                    tv_rating.setText(String.valueOf(yearlist.get(i).rating));
                    tv_year.setText(String.valueOf(yearlist.get(i).myear));
                    tv_imdb.setText(yearlist.get(i).mimdb);
                }

            }
        });

        iv_prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (i == 0) {
                    Toast.makeText(ByYear_Activity.this, "First movie", Toast.LENGTH_SHORT).show();
                } else {
                    i--;
                    tv_title.setText(yearlist.get(i).mname);
                    tv_desc.setText(yearlist.get(i).mdesc);
                    tv_genre.setText(yearlist.get(i).genre);
                    tv_rating.setText(String.valueOf(yearlist.get(i).rating));
                    tv_year.setText(String.valueOf(yearlist.get(i).myear));
                    tv_imdb.setText(yearlist.get(i).mimdb);

                }

            }
        });

        iv_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (i == j - 1) {
                    Toast.makeText(ByYear_Activity.this, "Last movie", Toast.LENGTH_SHORT).show();
                } else {
                    i++;

                    if (i < j) {
                        tv_title.setText(yearlist.get(i).mname);
                        tv_desc.setText(yearlist.get(i).mdesc);
                        tv_genre.setText(yearlist.get(i).genre);
                        tv_rating.setText(String.valueOf(yearlist.get(i).rating));
                        tv_year.setText(String.valueOf(yearlist.get(i).myear));
                        tv_imdb.setText(yearlist.get(i).mimdb);
                    } else {
                        Toast.makeText(ByYear_Activity.this, "Last movie", Toast.LENGTH_SHORT).show();
                    }

                }
            }
        });

        iv_last.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (i == j - 1) {
                    Toast.makeText(ByYear_Activity.this, "Last movie", Toast.LENGTH_SHORT).show();
                } else {
                    i = j - 1;
                    tv_title.setText(yearlist.get(i).mname);
                    tv_desc.setText(yearlist.get(i).mdesc);
                    tv_genre.setText(yearlist.get(i).genre);
                    tv_rating.setText(String.valueOf(yearlist.get(i).rating));
                    tv_year.setText(String.valueOf(yearlist.get(i).myear));
                    tv_imdb.setText(yearlist.get(i).mimdb);
                }
            }
        });

        bt_finsih.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }
    }

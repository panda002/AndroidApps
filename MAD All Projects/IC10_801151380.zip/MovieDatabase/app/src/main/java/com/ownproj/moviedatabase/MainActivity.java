package com.ownproj.moviedatabase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private Button btadd;
    private Button btedit;
    private Button btdelete;
    private Button btlistyear;
    private Button btrating;
    int moview_details = 007;
    static int EDIT_REQUEST = 10;
    int i, j;
    static String KEY_YEAR = "year";
    static String KEY_RATING = "rating";
    private FirebaseFirestore db;
    //public ArrayList<Object> moviename=new ArrayList<>();
    private  AlertDialog alert;
    private ArrayList<Movies> movies = new ArrayList<>();
    private ArrayList<String> moviename = new ArrayList<>();
    private String[] mnames = new String[moviename.size()];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btadd = findViewById(R.id.bt_add);
        btedit = findViewById(R.id.bt_edit);
        btdelete = findViewById(R.id.bt_delete);
        btlistyear = findViewById(R.id.bt_listyear);
        btrating = findViewById(R.id.bt_rating);
        db = FirebaseFirestore.getInstance();

        db.collection("MoviesDatabase")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot queryDocumentSnapshot : Objects.requireNonNull(task.getResult())) {
                                Movies getMovie = new Movies(queryDocumentSnapshot.getData());
                                movies.add(getMovie);
                                moviename.add(getMovie.getMname());
                            }
                        }
                    }
                });



        btadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent addintent = new Intent(MainActivity.this, AddMovieActivity.class);
                startActivityForResult(addintent, moview_details);
            }
        });

        btedit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        editview();
            }
        });

        btdelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mnames = new String[moviename.size()];
                mnames = moviename.toArray(mnames);
                if (movies.size() > 0) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("Pick a movie")
                            .setItems(mnames, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, final int i) {
                                    final Movies movie = movies.get(i);
                                    db.collection("MoviesDatabase")
                                            .document(movie.getMid())
                                            .delete()
                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void aVoid) {
                                                    movies.remove(i);
                                                    moviename.remove(i);
                                                    Toast.makeText(MainActivity.this, "Movie ", Toast.LENGTH_SHORT).show();
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Log.d("onFailure", "onFailure: "+e);

                                        }
                                    });
                                }
                            });

                    alert = builder.create();
                    alert.show();
                } else {
                    Toast.makeText(MainActivity.this, "No movies to show", Toast.LENGTH_SHORT).show();
                }

            }
        });

        btlistyear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(movies.size()==0)
                {
                    Toast.makeText(MainActivity.this, "Please add movie to see", Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent year = new Intent(MainActivity.this, ByYear_Activity.class);
                    year.addCategory(Intent.CATEGORY_DEFAULT);
                    year.putExtra(KEY_YEAR, movies);
                    startActivity(year);
                }
            }
        });


        btrating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(movies.size()==0)
                {
                    Toast.makeText(MainActivity.this, "Please add movie to see", Toast.LENGTH_SHORT).show();
                }
                else {

                    Intent rating = new Intent(MainActivity.this, ByRating_Activity.class);
                    rating.addCategory(Intent.CATEGORY_DEFAULT);
                    rating.putParcelableArrayListExtra(KEY_RATING,  movies);
                    startActivity(rating);
                }
            }
        });

    }
    public void editview() {


        mnames = moviename.toArray(mnames);

        if (movies.size() > 0) {
            final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Pick a movie")
                    .setItems(mnames, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Movies movie = movies.get(i);
                            Intent EditmovieIntent = new Intent(MainActivity.this, EditMovie.class);
                            EditmovieIntent.putExtra("Moviedetails", movie);
                            EditmovieIntent.putExtra("movieid",movie.getMid());
                            startActivityForResult(EditmovieIntent, EDIT_REQUEST);
                            alert.dismiss();
                        }
                    });

            alert = builder.create();
            alert.show();
        } else {
            Toast.makeText(MainActivity.this, "No movies to edit.", Toast.LENGTH_SHORT).show();
        }
        /*db.collection("MoviesDatabase")
             .get()
             .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                 @Override
                 public void onComplete(@NonNull Task<QuerySnapshot> task) {
                    if (task.isSuccessful()) {
                      for (final QueryDocumentSnapshot document : task.getResult()) {
                          Log.d("Success", document.getId() + " => " + document.get("mname"));
                          //moviename.add(document.get("mname"));
                         }
                     }
                 }
            });

    if (moviename.isEmpty()) {
        Toast.makeText(MainActivity.this, "No movies added yet", Toast.LENGTH_SHORT).show();
    } else {
        final AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Pick a Movie");
        final String[] arr1 = new String[moviename.size()];
        builder.setItems(arr1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                for (j = 0; j < moviename.size(); j++) {
                    if (arr1[i].equals(moviename.get(j))) {
                        break;
                    }
                }
                Intent EditmovieIntent = new Intent(MainActivity.this, EditMovie.class);
                EditmovieIntent.putExtra("map", (String) moviename.get(j));
                startActivityForResult(EditmovieIntent, EDIT_REQUEST);
                alert.dismiss();
            }
        });
        alert = builder.create();
        alert.show();
    }*/
}



}



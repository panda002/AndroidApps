package com.ownproj.moviedatabase;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.Map;

//Sidharth
class Movies implements Parcelable {

    String mname;
    String mdesc;
    String genre;
    int rating;
    int myear;
    String mimdb;
    String mid;


    @Override
    public String toString() {
        return "Movies{" +
                "mname='" + mname + '\'' +
                ", mdesc='" + mdesc + '\'' +
                ", genre='" + genre + '\'' +
                ", rating=" + rating +
                ", myear=" + myear +
                ", mimdb='" + mimdb + '\'' +
                ", mid=" + mid +
                '}';
    }

public Movies(){}

    public Movies(String mname, String mdesc, String genre, int rating, int myear, String mimdb, String mid) {
        this.mname = mname;
        this.mdesc = mdesc;
        this.genre = genre;
        this.rating = rating;
        this.myear = myear;
        this.mimdb = mimdb;
        this.mid = mid;
    }

    public String getMname() {
        return mname;
    }

    public String getMdesc() {
        return mdesc;
    }

    public String getGenre() {
        return genre;
    }

    public int getRating() {
        return rating;
    }

    public int getMyear() {
        return myear;
    }

    public String getMimdb() {
        return mimdb;
    }

    public String getMid() {
        return mid;
    }

    public void setMname(String mname) {
        this.mname = mname;
    }

    public void setMdesc(String mdesc) {
        this.mdesc = mdesc;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public void setMyear(int myear) {
        this.myear = myear;
    }

    public void setMimdb(String mimdb) {
        this.mimdb = mimdb;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

/*    public Map<String, Object> toHashMap()
    {
        Map<String, Object>  moviemap = new HashMap<>();
        moviemap.put("mname", this.mname);
        moviemap.put("mdesc", this.mdesc);
        moviemap.put("genre", this.genre);
        moviemap.put("rating", this.rating);
        moviemap.put("myear", this.myear);
        moviemap.put("mimdb", this.mimdb);
        moviemap.put("mid", this.mid);

        return moviemap;

    }*/

    public Movies(Map mapMovies) {
        this.mname = (String) mapMovies.get("mname");
        this.mdesc = (String) mapMovies.get("mdesc");
        this.genre = (String) mapMovies.get("genre");
        this.rating = (int)(long) mapMovies.get("rating");
        this.myear = (int)(long)  mapMovies.get("myear");
        this.mimdb = (String) mapMovies.get("mimdb");
        this.mid = (String) mapMovies.get("mid");
    }

    protected Movies(Parcel in) {
        mname = in.readString();
        mdesc = in.readString();
        genre = in.readString();
        rating = in.readInt();
        myear = in.readInt();
        mimdb = in.readString();
        mid = in.readString();
    }

    public static final Parcelable.Creator<Movies> CREATOR = new Parcelable.Creator<Movies>() {
        @Override
        public Movies createFromParcel(Parcel in) {
            return new Movies(in);
        }

        @Override
        public Movies[] newArray(int size) {
            return new Movies[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(mname);
        parcel.writeString(mdesc);
        parcel.writeString(genre);
        parcel.writeInt( rating);
        parcel.writeInt(myear);
        parcel.writeString(mimdb);
        parcel.writeString(mid);
    }


}

package com.ownproj.moviedatabase;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SetOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

//Sidharth

public class AddMovieActivity extends AppCompatActivity {

    private String genre;
    private int seekbarprogress;
    private int ratingseekbarprogress;
    private String mname;
    private String mdesc;
    private Integer myear;
    private String mimdb;
    private TextView seekprogressnum;
    private EditText et_name,et_description,et_year,et_imdb;
    private Spinner spinner;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_movie_activity);

        et_name = findViewById(R.id.et_name);
        et_description = findViewById(R.id.et_description);
        spinner = findViewById(R.id.spinner);
        et_year = findViewById(R.id.et_year);
        et_imdb = findViewById(R.id.et_imdb);
        SeekBar seekBar = findViewById(R.id.seekBar);
        Button bt_addmovie = findViewById(R.id.bt_addmovie);
        seekprogressnum = findViewById(R.id.seekprogress);

        Android:setTitle("Add Movie");

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.genre_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                genre = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        seekBar.setProgress(0);
        seekBar.setMax(5);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                ratingseekbarprogress = i;
                seekprogressnum.setText(String.valueOf(i));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });



        bt_addmovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (et_name.getText().toString().isEmpty())

                {
                    Toast.makeText(AddMovieActivity.this, "Please enter a movie name", Toast.LENGTH_SHORT).show();
                }
                else if(et_description.getText().toString().isEmpty())
                {
                    Toast.makeText(AddMovieActivity.this,"Please enter the description",Toast.LENGTH_SHORT).show();
                }
                else if(genre.equals("Select"))
                {
                    Toast.makeText(AddMovieActivity.this,"Please enter a genre",Toast.LENGTH_SHORT).show();
                }
                else if ((et_year.getText().toString().isEmpty())||(et_year.getText().toString().length() < 4) ||(et_year.getText().toString().length()>4))
                {
                    Toast.makeText(AddMovieActivity.this, "Please enter a valid year", Toast.LENGTH_SHORT).show();
                }else if ((et_imdb.getText().toString().isEmpty())||(!(et_imdb.getText().toString().startsWith("https://www.imdb.com/")))) {
                    Toast.makeText(AddMovieActivity.this,"Please enter the IMDB link in the format https://www.imdb.com/",Toast.LENGTH_SHORT).show();
                }

                else{
                    addMovies();
                    Toast.makeText(AddMovieActivity.this, mname+ " added successfully", Toast.LENGTH_SHORT).show();
                    finish();
                }


            }
        });
    }
    public void addMovies(){
        mname = et_name.getText().toString();
        mdesc = et_description.getText().toString();
        myear = Integer.parseInt(et_year.getText().toString());
        mimdb = et_imdb.getText().toString();

       /* Map<String, Object>  moviemap = new HashMap<>();
        moviemap.put("mname", mname);
        moviemap.put("mdesc", mdesc);
        moviemap.put("genre", genre);
        moviemap.put("rating", ratingseekbarprogress);
        moviemap.put("myear", myear);
        moviemap.put("mimdb", mimdb);
        moviemap.put("mid", mid);*/

        //Movies movies = new Movies();

        Movies movies = new Movies();
        movies.setMname(mname);
        movies.setMdesc(mdesc);
        movies.setGenre(genre);
        movies.setRating(ratingseekbarprogress);
        movies.setMyear(myear);
        movies.setMimdb(mimdb);
        String did = mname + myear + ratingseekbarprogress;
        movies.setMid(did);

        db.collection("MoviesDatabase")
                .document(movies.getMid())
                .set(movies)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Log.d("Succ", "DocumentSnapshot written with ID: " + task.getResult());
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.w("Fail", "Error adding document", e);
            }
        });

/*        db.collection("MoviesDatabase").add(movies)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.d("Succ", "DocumentSnapshot written with ID: " + documentReference.getId());
                        mid = documentReference.getId();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w("Fail", "Error adding document", e);
                    }
                });*/

        //Toast.makeText(AddMovieActivity.this, "Movie "+mname+" Successfully added", Toast.LENGTH_SHORT).show();
    }

}

package com.ownproj.moviedatabase;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

//Sidharth Panda

public class EditMovie extends AppCompatActivity {
    private String genre;
    private int seekbarprogress;
    private int ratingseekbarprogress;
    private String mname;
    private String mdesc;
    private Integer myear;
    private String mimdb;
    private TextView seekprogress;
    private EditText et_name;
    private EditText et_description;
    private Spinner  spinner;
    private EditText et_year;
    private EditText et_imdb;
    private SeekBar  seekBar;
    private Button   bt_editmovie;
    private FirebaseFirestore db;

    private String docid = "";
    //private CollectionReference movieref = db.collection("MoviesDatabase");

    Movies movies = new Movies();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_movie);
        android:setTitle("Edit Movie");

         et_name = findViewById(R.id.et_name);
         et_description= findViewById(R.id.et_description);
         spinner = findViewById(R.id.spinner);
         et_year= findViewById(R.id.et_year);
         et_imdb= findViewById(R.id.et_imdb);
         seekBar= findViewById(R.id.seekBar);
         bt_editmovie= findViewById(R.id.bt_addmovie);
         seekprogress = findViewById(R.id.seekprogress);
         db = FirebaseFirestore.getInstance();


        if (getIntent() != null && getIntent().getExtras() != null) {
            movies = getIntent().getExtras().getParcelable("Moviedetails");
            docid =getIntent().getStringExtra("movieid");
        }

        db.collection("MoviesDatabase").document(docid)
                .get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        Movies getdata = new Movies(documentSnapshot.getData());
                        Toast.makeText(EditMovie.this, " "+documentSnapshot.getData(), Toast.LENGTH_SHORT).show();
                        et_name.setText(getdata.getMname());
                        et_description.setText(getdata.getMdesc());
                        seekBar.setProgress(getdata.getRating());
                        seekprogress.setText(String.valueOf(getdata.getRating()));
                        et_year.setText(String.valueOf(getdata.getMyear()));
                        et_imdb.setText(getdata.getMimdb());
                        genre = getdata.getGenre();
                        switch (genre) {
                            case "Select":
                                spinner.setSelection(0);
                                break;
                            case "Action":
                                spinner.setSelection(1);
                                break;
                            case "Animation":
                                spinner.setSelection(2);
                                break;
                            case "Comedy":
                                spinner.setSelection(3);
                                break;
                            case "Documentary":
                                spinner.setSelection(4);
                                break;
                            case "Family":
                                spinner.setSelection(5);
                                break;
                            case "Horror":
                                spinner.setSelection(6);
                                break;
                            case "Crime":
                                spinner.setSelection(7);
                                break;
                            case "Others":
                                spinner.setSelection(8);
                                break;
                        }
                    }
                });





        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(EditMovie.this, R.array.genre_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        int spinnerPosition = adapter.getPosition(genre);
        spinner.setSelection(spinnerPosition);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                genre = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                ratingseekbarprogress = i;
                seekprogress.setText(String.valueOf(i));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    bt_editmovie.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            if (et_name.getText().toString().isEmpty())

            {
                Toast.makeText(EditMovie.this, "Please enter a movie name", Toast.LENGTH_SHORT).show();
            }
            else if(et_description.getText().toString().isEmpty())
            {
                Toast.makeText(EditMovie.this,"Please enter the description",Toast.LENGTH_SHORT).show();
            }
            else if(genre.equals("Select"))
            {
                Toast.makeText(EditMovie.this,"Please enter a genre",Toast.LENGTH_SHORT).show();
            }
            else if ((et_year.getText().toString().isEmpty())||(et_year.getText().toString().length() < 4) ||(et_year.getText().toString().length()>4))
            {
                Toast.makeText(EditMovie.this, "Please enter a valid year", Toast.LENGTH_SHORT).show();
            }else if ((et_imdb.getText().toString().isEmpty())||(!(et_imdb.getText().toString().startsWith("https://www.imdb.com/")))) {
            Toast.makeText(EditMovie.this,"Please enter the IMDB link in the format https://www.imdb.com/",Toast.LENGTH_SHORT).show();
            }

            else{
                editMovies();
                finish();
            }


        }
    });
}
    public void editMovies(){
        mname = et_name.getText().toString();
        mdesc = et_description.getText().toString();
        myear = Integer.parseInt(et_year.getText().toString());
        mimdb = et_imdb.getText().toString();

/*        Map<String, Object>  moviemap = new HashMap<>();
        moviemap.put("mname", mname);
        moviemap.put("mdesc", mdesc);
        moviemap.put("genre", genre);
        moviemap.put("rating", ratingseekbarprogress);
        moviemap.put("myear", myear);
        moviemap.put("mimdb", mimdb);
        moviemap.put("mid", docid);*/

        Movies movies = new Movies();
        movies.setMname(mname);
        movies.setMdesc(mdesc);
        movies.setGenre(genre);
        movies.setRating(ratingseekbarprogress);
        movies.setMyear(myear);
        movies.setMimdb(mimdb);
        movies.setMid(docid);

        db.collection("MoviesDatabase").document(docid)
                .set(movies)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(EditMovie.this, "mname "+mname+" updated", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

        //Movies movies = new Movies(mname,mdesc,genre,ratingseekbarprogress,myear,mimdb,docid);
/*        db.collection("MoviesDatabase")
                .document(docid)
                .update(moviemap)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(EditMovie.this, "mname "+mname+" updated", Toast.LENGTH_SHORT).show();
                    }
                });*/
    }

}

package com.ownproj.moviedatabase;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Objects;

//Sidharth

public class ByRating_Activity extends AppCompatActivity {

    private TextView tv_title, tv_desc, tv_genre, tv_rating, tv_year, tv_imdb;
    private ImageView iv_prev;
    private ImageView  iv_next;
    private ImageView  iv_last;
    private ImageView   iv_first;
    private Button bt_finsih;
    ArrayList<Movies> mlist= new ArrayList<>();
    int i=0;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private ArrayList<Movies> ratinglist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_by_rating_);
        android:
        setTitle("Movies by Rating");
        tv_title = findViewById(R.id.tv_title);
        tv_desc = findViewById(R.id.tv_description);
        tv_rating = findViewById(R.id.tv_rating);
        tv_year = findViewById(R.id.tv_year);
        tv_imdb = findViewById(R.id.tv_Imdb);
        iv_next = findViewById(R.id.iv_next);
        iv_last = findViewById(R.id.iv_last);
        tv_genre = findViewById(R.id.tv_genre);
        bt_finsih = findViewById(R.id.bt_finish);
        iv_first = findViewById(R.id.iv_first);
        iv_prev = findViewById(R.id.iv_prev);

        db.collection("MoviesDatabase")
                .orderBy("rating", Query.Direction.DESCENDING)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            ratinglist = new ArrayList<>();
                            for (QueryDocumentSnapshot queryDocumentSnapshot : Objects.requireNonNull(task.getResult())) {
                                Movies getdata = new Movies(queryDocumentSnapshot.getData());
                                ratinglist.add(getdata);
                            }
                            showbyrating();
                        }
                    }
                });

    }
        public void showbyrating(){
            final int j = ratinglist.size();

            i = 0;
            tv_title.setText(ratinglist.get(i).mname);
            tv_desc.setText(ratinglist.get(i).mdesc);
            tv_genre.setText(ratinglist.get(i).genre);
            tv_rating.setText(String.valueOf(ratinglist.get(i).rating));
            tv_year.setText(String.valueOf(ratinglist.get(i).myear));
            tv_imdb.setText(ratinglist.get(i).mimdb);

            iv_first.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (i == 0) {
                        Toast.makeText(ByRating_Activity.this, "First movie", Toast.LENGTH_SHORT).show();
                    } else {
                        i = 0;

                        tv_title.setText(ratinglist.get(i).mname);
                        tv_desc.setText(ratinglist.get(i).mdesc);
                        tv_genre.setText(ratinglist.get(i).genre);
                        tv_rating.setText(String.valueOf(ratinglist.get(i).rating));
                        tv_year.setText(String.valueOf(ratinglist.get(i).myear));
                        tv_imdb.setText(ratinglist.get(i).mimdb);
                    }

                }
            });

            iv_prev.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (i == 0) {
                        Toast.makeText(ByRating_Activity.this, "First movie", Toast.LENGTH_SHORT).show();
                    } else {
                        i--;
                        tv_title.setText(ratinglist.get(i).mname);
                        tv_desc.setText(ratinglist.get(i).mdesc);
                        tv_genre.setText(ratinglist.get(i).genre);
                        tv_rating.setText(String.valueOf(ratinglist.get(i).rating));
                        tv_year.setText(String.valueOf(ratinglist.get(i).myear));
                        tv_imdb.setText(ratinglist.get(i).mimdb);

                    }

                }
            });

            iv_next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (i == j - 1) {
                        Toast.makeText(ByRating_Activity.this, "Last movie", Toast.LENGTH_SHORT).show();
                    } else {
                        i++;

                        if (i < j) {
                            tv_title.setText(ratinglist.get(i).mname);
                            tv_desc.setText(ratinglist.get(i).mdesc);
                            tv_genre.setText(ratinglist.get(i).genre);
                            tv_rating.setText(String.valueOf(ratinglist.get(i).rating));
                            tv_year.setText(String.valueOf(ratinglist.get(i).myear));
                            tv_imdb.setText(ratinglist.get(i).mimdb);
                        } else {
                            Toast.makeText(ByRating_Activity.this, "Last movie", Toast.LENGTH_SHORT).show();
                        }

                    }
                }
            });

            iv_last.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (i == j - 1) {
                        Toast.makeText(ByRating_Activity.this, "Last movie", Toast.LENGTH_SHORT).show();
                    } else {
                        i = j - 1;
                        tv_title.setText(ratinglist.get(i).mname);
                        tv_desc.setText(ratinglist.get(i).mdesc);
                        tv_genre.setText(ratinglist.get(i).genre);
                        tv_rating.setText(String.valueOf(ratinglist.get(i).rating));
                        tv_year.setText(String.valueOf(ratinglist.get(i).myear));
                        tv_imdb.setText(ratinglist.get(i).mimdb);
                    }
                }
            });

            bt_finsih.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });


        }
}

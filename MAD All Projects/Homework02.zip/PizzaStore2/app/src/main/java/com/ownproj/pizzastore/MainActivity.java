package com.ownproj.pizzastore;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;


import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    private Button bt_clear;
    private Button bt_addtopping;
    private Button bt_checkout;
    private CheckBox cb_delivery;
    //private GridView gridView;
    AlertDialog.Builder builder;
    AlertDialog dialog;
    ProgressBar progressBar;
    String[] topping = {"Bacon", "Cheese", "Garlic", "Green Pepper", "Mushroom", "Olives", "Onions", "Red Pepper"};
    LinearLayout topfirst, topsecond;
    ArrayList<Integer> toppingimage = new ArrayList<Integer>
            (Arrays.asList(R.drawable.bacon,R.drawable.cheese,R.drawable.garlic,
                    R.drawable.green_pepper,R.drawable.mashroom,R.drawable.olive,
                    R.drawable.onion,R.drawable.red_pepper));
    ArrayList<String> selectedtoppings = new ArrayList<String>();
    LinearLayout.LayoutParams params;
    int toppingnum = 0;

    public final static Double BASE_PIZZA_COST=6.50;
    public final static Double TOPPING_COST=1.50;
    public final static Double DELIVERY_COST=4.00;
    public final static Integer REQUEST_CODE=400;

    //"Bacon","Cheese","Garlic","Green Pepper","Mushroom"
            //,"Olives","Onions", "Red Pepper"

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);

        bt_clear = findViewById(R.id.bt_clearpizza);
        bt_addtopping = findViewById(R.id.bt_addtopping);
        bt_checkout = findViewById(R.id.bt_checkout);
        cb_delivery = findViewById(R.id.ck_delivery);
        topfirst = findViewById(R.id.topfirst);
        topsecond = findViewById(R.id.topsecond);
        progressBar = findViewById(R.id.progressBar);

        final float scale = getResources().getDisplayMetrics().density;
        params = new LinearLayout.LayoutParams((int)(60*scale), (int)(60*scale));

        builder = new AlertDialog.Builder(MainActivity.this);

        builder.setTitle(R.string.Dialog_alert_title);
        builder.setItems(topping, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                Log.d("Demo", "onClick: ");
                params.weight = 0.0f;
                ImageView selectedtopimage = new ImageView(MainActivity.this);
                progressBar.setProgress(++toppingnum,true);
               //progressBar.setProgress(toppingnum,true);
                selectedtopimage.setLayoutParams(params);
                selectedtopimage.setImageDrawable(getDrawable(toppingimage.get(i)));
                selectedtoppings.add(topping[i]);

                selectedtopimage.setTag(topping[i]);
                selectedtopimage.setOnClickListener(MainActivity.this);

                if(toppingnum <= 5) {
                    topfirst.addView(selectedtopimage);
                }else if(toppingnum <= 10){
                    topsecond.addView(selectedtopimage);
                }
                if(toppingnum >= 10) {
                    Toast toast = Toast.makeText(MainActivity.this, R.string.toast_warning, Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        })
        .setCancelable(true)
        ;
        bt_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toppingnum = 0;
                selectedtoppings.clear();
                topfirst.removeAllViews();
                topsecond.removeAllViews();
                //
                progressBar.setProgress(0,true);
                //
            }
        });

        dialog = builder.create();
        bt_addtopping.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Perform action on click
                if(toppingnum >= 10) {
                    Toast toast = Toast.makeText(MainActivity.this, R.string.toast_error, Toast.LENGTH_SHORT);
                    toast.show();
                }else {
                    dialog.show();
                }
            }
        });

        bt_checkout.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(toppingnum==0){
                    Toast.makeText(getApplicationContext(),R.string.checkout_warning,Toast.LENGTH_SHORT).show();
                }
                else{
                    Intent intentFromMainToOrder=new Intent(MainActivity.this,OrderActivity.class);
                    Double totalToppingCost=(Double) (toppingnum*TOPPING_COST);

                    Double totalCost=totalToppingCost+BASE_PIZZA_COST;
                    Bundle sendData=new Bundle();
                    sendData.putStringArrayList("ToppingList",selectedtoppings);
                    if(cb_delivery.isChecked()){

                        totalCost=totalCost+DELIVERY_COST;
                        sendData.putString("DELIVERY_COST",String.valueOf(DELIVERY_COST+"$"));
                        sendData.putString("TOTAL_COST",String.valueOf(totalCost+"$"));
                        sendData.putString("TOPPINGS_COST",String.valueOf(totalToppingCost+"$"));

                    }
                    else{
                        sendData.putString("DELIVERY_COST",String.valueOf(0.00+"$"));
                        sendData.putString("TOTAL_COST",String.valueOf(totalCost+"$"));
                        sendData.putString("TOPPINGS_COST",String.valueOf(totalToppingCost+"$"));
                    }
                    intentFromMainToOrder.putExtras(sendData);
                    startActivity(intentFromMainToOrder);
                    //startActivityForResult(intentFromMainToOrder,REQUEST_CODE);
                }

            }
        }));

    }

    @Override
    public void onClick(View v) {
        LinearLayout currentSelectedLayout = findViewById(((View) v.getParent()).getId());

        if(currentSelectedLayout==topsecond){
            currentSelectedLayout.removeView(v);//remove if image belongs to 2nd row
        }
        else{
           //check if number of images in topsecond is greater than 0
            if(topsecond.getChildCount()!=0){

                currentSelectedLayout.removeView(v);//remove the image
                ImageView v1=(ImageView)topsecond.getChildAt(0);//capture image at 0th index (topsecond)
                topsecond.removeView(v1);//remove the 0th index image (topsecond)
                topfirst.addView(v1);//add the image at the end of topfirst
            }
            else{ //remove the image when topsecond is empty
                currentSelectedLayout.removeView(v);

            }

        }

        progressBar.setProgress(--toppingnum,true);
        selectedtoppings.remove(v.getTag());


    }


}

package com.ownproj.pizzastore;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class OrderActivity extends AppCompatActivity {

    Button btn_finish;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        final TextView tv_basePrice=findViewById(R.id.tv_basePrice_value);
        final TextView tv_toppings_cost=findViewById(R.id.tv_topping_cost_value);
        final TextView tv_toppings_list=findViewById(R.id.tv_toppings_list);
        final TextView tv_delivery_cost=findViewById(R.id.tv_delivery_cost_value);
        final TextView tv_total_cost=findViewById(R.id.tv_total_cost);
        btn_finish=findViewById(R.id.btn_finish);

        final Bundle extrasFromBundle=getIntent().getExtras();
        ArrayList<String> stringArray=extrasFromBundle.getStringArrayList("ToppingList");
        tv_toppings_list.setText(stringArray.toString());
        final String totalCost=extrasFromBundle.getString("TOTAL_COST");
        tv_total_cost.setPaintFlags(tv_total_cost.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        tv_total_cost.setText(totalCost);
        final String deliveryCost=extrasFromBundle.getString("DELIVERY_COST");
        tv_delivery_cost.setText(deliveryCost);
        final String basePizzaCost=String.valueOf(MainActivity.BASE_PIZZA_COST+"$");
        tv_basePrice.setText(basePizzaCost);
        tv_toppings_cost.setText(extrasFromBundle.getString("TOPPINGS_COST"));

        btn_finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(OrderActivity.this,MainActivity.class);
                //setResult(RESULT_OK);

                finish();
                startActivity(i);
            }
        });


    }
}

package com.example.inclass09;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ChatScreenActivity extends AppCompatActivity {

    ImageView iv_newEmail;
    ImageView iv_logout;
    TextView tv_fullName;
    RecyclerView rv_list_email;
    RecyclerView.Adapter rv_adapter;
    RecyclerView.LayoutManager rv_layout;
    UserResponse userResponse;
    ArrayList<MessageResponse> mResponseList;
    List<MessageResponse> mR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_screen);
        setTitle("Inbox");

        iv_newEmail=(ImageView)findViewById(R.id.iv_new_email);
        iv_logout=(ImageView)findViewById(R.id.iv_logout);
        tv_fullName=(TextView)findViewById(R.id.tv_fullName);
        rv_list_email=(RecyclerView)findViewById(R.id.rv_email_list);
        rv_list_email.setHasFixedSize(true);
        rv_layout=new LinearLayoutManager(this);
        rv_list_email.setLayoutManager(rv_layout);


        if (getIntent().getExtras() != null) {
            userResponse = (UserResponse) getIntent().getExtras().getSerializable("USER_OBJ");
           // String token=userResponse.getToken();
        SharedPreferences sharedPref = MainActivity.sharedPreferences;
        String token=sharedPref.getString("USER_TOKEN",null);

            tv_fullName.setText(userResponse.getUser_fname()+" "+userResponse.getUser_lname());
            Log.d("Token",token);
            OkHttpClient fetchEmails=new OkHttpClient();

            Request requestForEmails=new Request.Builder()
                    .url("http://ec2-18-234-222-229.compute-1.amazonaws.com/api/inbox")
                    .header("Authorization","BEARER "+token)
                    .build();

            fetchEmails.newCall(requestForEmails).enqueue(new Callback() {
                @Override
                public void onFailure(@NotNull Call call, @NotNull IOException e) {

                    ChatScreenActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "Invalid request for Emails", Toast.LENGTH_SHORT).show();
                        }
                    });


                }

                @Override
                public void onResponse(@NotNull Call call, @NotNull final Response response) throws IOException {

                    if(response.isSuccessful()){

                        String json=response.body().string();
                        JsonObject jsonObject = new Gson().fromJson(json, JsonObject.class);
                        JsonArray jsonArray = jsonObject.getAsJsonArray("messages");


                        MessageResponse[] messageResponse=new Gson().fromJson(jsonArray,MessageResponse[].class);
                        //mResponseList.add(messageResponse);
                        mR=new ArrayList<>();
                        mR=Arrays.asList(messageResponse);
                        if(mR.size()==0){
                            ChatScreenActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getApplicationContext(),"No New Messages",Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                        else {

                            ChatScreenActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    rv_adapter = new EmailRecycleAdapter(mR, userResponse);
                                    rv_list_email.setAdapter(rv_adapter);


                                }
                            });


                        }



                      //  Log.d("MR0",mR.get(0).toString());
                       // Log.d("MR1",mR.get(1).toString());








                    }
                    else{
                       ChatScreenActivity.this.runOnUiThread(new Runnable() {
                           @Override
                           public void run() {
                               Toast.makeText(getApplicationContext(),response.message(),Toast.LENGTH_SHORT).show();
                           }
                       });

                    }

                }
            });

            iv_newEmail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent toCreateNewEmailActivity=new Intent(ChatScreenActivity.this, CreateNewEmailActivity.class);
                    toCreateNewEmailActivity.putExtra("USER_OBJ",userResponse);
                    startActivity(toCreateNewEmailActivity);
                }
            });

            iv_logout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent toLoginScreen=new Intent(ChatScreenActivity.this,MainActivity.class);
                    startActivity(toLoginScreen);
                    finish();
                }
            });

        }

        else{

            Toast.makeText(getApplicationContext(),"Not Authorized",Toast.LENGTH_SHORT).show();
        }

    //implement onClick for Create new Email, should go to CreateNewEmailActivity



    }


}

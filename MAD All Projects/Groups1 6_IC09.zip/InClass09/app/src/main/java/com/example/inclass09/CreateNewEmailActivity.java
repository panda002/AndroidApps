package com.example.inclass09;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

import static com.example.inclass09.MainActivity.sharedPreferences;

public class CreateNewEmailActivity extends AppCompatActivity {

    Button bt_send;
    Button bt_cancel;
    EditText et_subject;
    EditText et_body;
    Spinner user_spinner;
    String token;
    Map<String,String> users = new LinkedHashMap<String, String>(); // //reference taken from - https://github.com/ankit-kejriwal/InClass09/blob/master/app/src/main/java/com/example/inclass09/Compose.java

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_new_email);
        setTitle("Create New Email");

        bt_send = findViewById(R.id.bt_send);
        bt_cancel = findViewById(R.id.bt_cancel);
        et_subject = findViewById(R.id.et_subject);
        et_body = findViewById(R.id.et_body);
        user_spinner = findViewById(R.id.user_spinner);
        //Add spinner, fetch the list of users using http://ec2-18-234-222-229.compute-1.amazonaws.com/api/users,
        //For POST request, pass the token from UserResponse instance
        //Due to server anomalies, adding a new message will not return the status code 200/201 (successful). Rather it will return a code 500. So, if you receive the code 500, ignore it from the catched exception and get back to Inbox screen.

        bt_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = "16";
                String subj =et_subject.getText().toString();
                String body =et_body.getText().toString();
                new getAsync().execute(id,subj,body);
            }
        });

        bt_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(CreateNewEmailActivity.this);;
        token=sharedPref.getString("USER_TOKEN",null);

        final OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url("http://ec2-18-234-222-229.compute-1.amazonaws.com/api/users")
                .addHeader("Authorization","BEARER "+token)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override public void onResponse(Call call, Response response) throws IOException {
                try (ResponseBody responseBody = response.body()) {
                    if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

                    Headers responseHeaders = response.headers();
                    for (int i = 0, size = responseHeaders.size(); i < size; i++) {
                        System.out.println(responseHeaders.name(i) + ": " + responseHeaders.value(i));
                    }

                    String  obj = response.body().string();
                    JSONObject Jobject = new JSONObject(obj);
                    JSONArray usersArray = Jobject.getJSONArray("users");
                    for(int i=0;i<usersArray.length();i++){
                        JSONObject emailJSON = usersArray.getJSONObject(i);
                        String fname = emailJSON.getString("fname");
                        String lname = emailJSON.getString("lname");
                        String id = emailJSON.getString("id");
                        users.put(id,fname+" "+lname);
                    }
                    final List userList = new ArrayList(users.values());
                    CreateNewEmailActivity.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            ArrayAdapter<String> adapter = new ArrayAdapter<String>(CreateNewEmailActivity.this,android.R.layout.simple_spinner_item, userList);
                            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            user_spinner.setAdapter(adapter);
                        }
                    });
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private class getAsync extends AsyncTask<String,Void,String>{

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(CreateNewEmailActivity.this, "Email has been sent", Toast.LENGTH_SHORT).show();
            finish();
        }

        @Override
        protected String doInBackground(String... strings) {
            final OkHttpClient client = new OkHttpClient();
            try { RequestBody formBody = new FormBody.Builder()
                    .add("rid", strings[0])
                    .add("subject", strings[0])
                    .add("emailbody", strings[1])
                    .build();
                Request request = new Request.Builder()
                        .url("http://ec2-18-234-222-229.compute-1.amazonaws.com/api/inbox/add")
                        .addHeader("Authorization","BEARER "+token)
                        .post(formBody)
                        .build();

                Response response = client.newCall(request).execute();
                if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);
                else{
                    String  obj = response.body().string();
                    return obj;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

    }

    //reference taken from - https://github.com/ankit-kejriwal/InClass09/blob/master/app/src/main/java/com/example/inclass09/Compose.java

}

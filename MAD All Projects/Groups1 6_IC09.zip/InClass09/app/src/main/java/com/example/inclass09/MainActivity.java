package com.example.inclass09;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


// Nayana and Sidharth
//Groups1 6
public class MainActivity extends AppCompatActivity {

    EditText et_email;
    EditText et_password;
    Button btn_login;
    Button btn_signup;
   // private static GsonBuilder gsonBuilder = new GsonBuilder();
    //public static Gson gson = gsonBuilder.create();


    public static SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        et_email=(EditText)findViewById(R.id.et_username);
        et_password=(EditText)findViewById(R.id.et_password);
        btn_login=(Button)findViewById(R.id.btn_login);
        btn_signup=(Button)findViewById(R.id.btn_signup);

        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent toSignUpActivity=new Intent(MainActivity.this,SignUpActivity.class);
                startActivity(toSignUpActivity);
                finish();
            }
        });

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                User u=new User();

                u.username=et_email.getText().toString();
                u.password=et_password.getText().toString();

                if (u.username.equals("")) {
                    Toast.makeText(getApplicationContext(), "Please enter email id", Toast.LENGTH_SHORT).show();
                } else if (u.password.equals("")) {
                    Toast.makeText(getApplicationContext(), "Please enter password.", Toast.LENGTH_SHORT).show();
                } else {

                    new GetLoginStatus().execute(u);
                }



               // String[] loginDetails={username,password};



            }
        });



    }

    private class GetLoginStatus extends AsyncTask<User, Void, String>{




        @Override
        protected String doInBackground(User... strings) {



            String url="http://ec2-18-234-222-229.compute-1.amazonaws.com/api/login";

            OkHttpClient loginHttpCall=new OkHttpClient();


          RequestBody formBody=new FormBody.Builder()
                    .add("email",strings[0].username.toString())
                    .add("password",strings[0].password.toString())
                    .build();

            Log.d("Login",strings[0].username.toString());

            Request request=new Request.Builder()
                    .url(url)
                   .post(formBody)
                    .build();
            Response response=null;
            try{
                response=loginHttpCall.newCall(request).execute();
                if(response.isSuccessful()){

                    //return "LoginSuccess";

                    return response.body().string();




}
                else{

                    return "NotSuccess";
                }


            }

            catch(IOException e){
                e.printStackTrace();

            }
            return null;

        }

        @Override
        protected void onPostExecute(String s) {
            //super.onPostExecute(s);
           Log.d("Response",s.toString());

           if(s=="NotSuccess"){

               Toast.makeText(getApplicationContext(),"Login Not Successful",Toast.LENGTH_SHORT).show();

           }

           else{

               Gson gson=new Gson();
                UserResponse userResponse = gson.fromJson(s, UserResponse.class);


                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    //editor.putString(USER_OBJ, MainActivity.gson.toJson(userResponse));
               editor.putString("USER_TOKEN",userResponse.getToken());
                    editor.apply();


                        Intent intent = new Intent(MainActivity.this, ChatScreenActivity.class);
                        intent.putExtra("USER_OBJ", userResponse);
                        startActivity(intent);


           }





        }
    }
}

package com.example.inclass09;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.Gson;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.BufferedSink;

public class SignUpActivity extends AppCompatActivity {

    EditText et_firstName;
    EditText et_lastName;
    EditText et_email;
    EditText et_choosePassword;
    EditText et_confirmPassword;
    Button btn_signUp;
    Button btn_cancel;
    public static SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        et_firstName=(EditText)findViewById(R.id.et_firstName);
        et_lastName=(EditText)findViewById(R.id.et_lastname);
        et_email=(EditText)findViewById(R.id.et_email);
        et_choosePassword=(EditText)findViewById(R.id.et_choosePassword);
        et_confirmPassword=(EditText)findViewById(R.id.et_confirmPassword);
        btn_cancel=(Button)findViewById(R.id.btn_cancel);
        btn_signUp=(Button)findViewById(R.id.btn_signup);


        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent toLoginActivity=new Intent(SignUpActivity.this,MainActivity.class);
                startActivity(toLoginActivity);
                finish();
            }
        });

        btn_signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String firstName = String.valueOf(et_firstName.getText());
                String lastName = String.valueOf(et_lastName.getText());
                String email = String.valueOf(et_email.getText());
                String password = String.valueOf(et_choosePassword.getText());
                String confirmPassword = String.valueOf(et_confirmPassword.getText());

                if (firstName.equals("") || lastName.equals("") || email.equals("") || password.equals("") || confirmPassword.equals("")) {
                    Toast.makeText(getApplicationContext(), "Please enter all inputs", Toast.LENGTH_SHORT).show();
                } else if (!password.equals(confirmPassword)) {
                    Toast.makeText(getApplicationContext(), "Password does not match", Toast.LENGTH_SHORT).show();
                } else {

                   // Signup(eml, pass, fName, lName);
                      //  SignUpAction(firstName,lastName,email,password,confirmPassword);



                    OkHttpClient registerHttpClient=new OkHttpClient();
                    String regURL="http://ec2-18-234-222-229.compute-1.amazonaws.com/api/signup";

                    RequestBody formBody=new FormBody.Builder()
                            .add("email",email)
                            .add("password",password)
                            .add("fname",firstName)
                            .add("lname",lastName)
                            .build();

                    Request request = new Request.Builder()
                            .url(regURL)
                            .post(formBody)
                            .addHeader("content-type","x-www-form-urlencoded")
                            .build();

                    registerHttpClient.newCall(request)
                            .enqueue(new Callback() {
                                @Override
                                public void onFailure(final Call call, IOException e) {
                                    // Error

                                   SignUpActivity.this.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(getApplicationContext(), "Invalid Input Passed", Toast.LENGTH_SHORT).show();

                                        }
                                    });
                                }

                                @Override
                                public void onResponse(Call call, final Response response) throws IOException {
                                    //String res = response.body().string();

                                    if(!response.isSuccessful()){
                                        Toast.makeText(getApplicationContext(),response.message(),Toast.LENGTH_SHORT).show();
                                    }
                                    else{


                                        Gson gson=new Gson();
                                        UserResponse userResponse = gson.fromJson(response.body().string(), UserResponse.class);


                                        SharedPreferences.Editor editor = sharedPreferences.edit();
                                        //editor.putString(USER_OBJ, MainActivity.gson.toJson(userResponse));
                                        editor.putString("USER_TOKEN",userResponse.getToken());
                                        editor.apply();


                                        Intent intent = new Intent(SignUpActivity.this, ChatScreenActivity.class);
                                        intent.putExtra("USER_OBJ", userResponse);
                                        startActivity(intent);
                                        finish();
                                        SignUpActivity.this.runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                Toast.makeText(getApplicationContext(),"New User Created",Toast.LENGTH_SHORT).show();
                                            }
                                        });


                                    }



                                }
                            });



                }
            }
        });


    }





}

package com.example.inclass09;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class DisplayEmailActivity extends AppCompatActivity {

    TextView tv_subject;
    TextView tv_message;
    TextView tv_sender;
    TextView tv_created_at;
    UserResponse userResponse;
    MessageResponse mResponse;
    Button btn_inbox;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_email);
        setTitle("DisplayEmail");

        tv_subject=(TextView)findViewById(R.id.tv_subject);
        tv_message=(TextView)findViewById(R.id.tv_message);
        tv_sender=(TextView)findViewById(R.id.tv_from_sender);
        tv_created_at=(TextView)findViewById(R.id.tv_created_at_date);
        btn_inbox=(Button)findViewById(R.id.btn_back);
        if (getIntent().getExtras() != null) {
            userResponse = (UserResponse) getIntent().getExtras().getSerializable("USER_OBJ");
            mResponse = (MessageResponse) getIntent().getExtras().getSerializable("MessageResponse");


            tv_subject.setText(mResponse.getSubject());
            tv_created_at.setText(mResponse.getCreatedAt());
            tv_sender.setText(mResponse.getSender_fname()+" "+mResponse.getSender_lname());
            tv_message.setText(mResponse.getMessage());

            btn_inbox.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent toChatScreen=new Intent(DisplayEmailActivity.this, ChatScreenActivity.class);
                    toChatScreen.putExtra("USER_OBJ",userResponse);
                    startActivity(toChatScreen);
                    finish();
                }
            });

        }
        else{
            Toast.makeText(getApplicationContext(),"Not Authorized", Toast.LENGTH_SHORT).show();
        }
        //Extract uRR and MessageResponse from Intent Serializable, pass Sender Name, Subject, Message, Created At text to UI

    }
}

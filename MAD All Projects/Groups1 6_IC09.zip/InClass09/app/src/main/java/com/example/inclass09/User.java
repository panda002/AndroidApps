package com.example.inclass09;

import androidx.annotation.NonNull;

public class User {

    String username, password;

    @NonNull
    @Override
    public String toString() {
        return username+password;
    }
}

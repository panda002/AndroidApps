package com.example.inclass09;

public class Messages {

    public MessageResponse getMessageResponse() {
        return messageResponse;
    }

    public void setMessageResponse(MessageResponse messageResponse) {
        this.messageResponse = messageResponse;
    }

    private MessageResponse messageResponse;


}

package com.example.inclass09;

import android.content.Intent;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class EmailRecycleAdapter extends RecyclerView.Adapter<EmailRecycleAdapter.ViewHolder>{

List<MessageResponse> mRList;
UserResponse ur;

public EmailRecycleAdapter(List<MessageResponse> mList, UserResponse uR){
    this.ur=uR;
    this.mRList=mList;
}

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.email_item,parent,false);
        ViewHolder viewHolder=new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MessageResponse mR=mRList.get(position);
        holder.tv_subject.setText(mR.getSubject());
        holder.tv_date_time.setText(mR.getCreatedAt());
        holder.deleteURL= "http://ec2-18-234-222-229.compute-1.amazonaws.com/api/inbox/delete/"+mR.getId();
        holder.mR=mR;
        holder.uRR=ur;

    }

    @Override
    public int getItemCount() {
        return mRList.size();
    }


    public static class ViewHolder extends  RecyclerView.ViewHolder{
        TextView tv_subject;
        TextView tv_date_time;
        ImageView iv_delete;
        String deleteURL;
        UserResponse uRR;
       MessageResponse mR;

        public ViewHolder (final View itemView){


            super(itemView);
            tv_subject=(TextView)itemView.findViewById(R.id.textView);
            tv_date_time=(TextView)itemView.findViewById(R.id.tv_date_time) ;
            iv_delete=(ImageView)itemView.findViewById(R.id.iv_delete);

            this.mR=mR;

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    //should go to display email activity
                    Intent i=new Intent(view.getContext(),DisplayEmailActivity.class);
                    i.putExtra("USER_OBJ",uRR);
                    i.putExtra("MessageResponse",mR);
                    view.getContext().startActivity(i);

                }
            });

            iv_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(final View view) {

                    OkHttpClient deleteHttpClient=new OkHttpClient();
                    Request requestForEmails=new Request.Builder()
                            .url(deleteURL)
                            .header("Authorization","BEARER "+uRR.getToken())
                            .build();

                    deleteHttpClient.newCall(requestForEmails).enqueue(new Callback() {
                        @Override
                        public void onFailure(@NotNull Call call, @NotNull IOException e) {

                        }

                        @Override
                        public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {

                            Intent intent = new Intent (view.getContext(), ChatScreenActivity.class);
                            intent.putExtra("USER_OBJ",uRR);
                            view.getContext().startActivity(intent);

                        }
                    });



                }
            });
        }
    }




}
